export type StatusPenguasaan = 'BELUM' | 'SEDANG' | 'MENGUASAI';

export interface KonstrukDefinisi {
  id: number;
  kod: string;
  tajuk: string;
  keterangan: string;
  contoh: string;
  warna: string;
}

export interface Murid {
  id: string;
  nama: string;
  noMyKid: string;
  jantina: 'Lelaki' | 'Perempuan';
  tahun: 'Tahun 1' | 'Tahun 2' | 'Tahun 3';
  kelas: string;
  namaPenjaga: string;
  noTelPenjaga: string;
  avatarChibi: string;
  bintang: number;
  lencana: string[];
  tahapKonstruk: Record<number, {
    status: StatusPenguasaan;
    peratus: number;
    tarikhSemakan: string;
    catatan?: string;
  }>;
  catatanGuru: string;
  tarikhDaftar: string;
}

export interface RekodAktiviti {
  id: string;
  muridId: string;
  namaMurid: string;
  konstrukId: number;
  tajukAktiviti: string;
  tarikh: string;
  markah: number;
  bilanganBetul: number;
  jumlahSoalan: number;
  tempohMasaSaat: number;
  status: StatusPenguasaan;
  jenisInteraksi: 'Seret & Lepas' | 'Klik & Padan';
}

export interface NotifikasiPeringatan {
  id: string;
  jenis: 'amaran_bimbingan' | 'kejayaan_lulus' | 'peringatan_ibu_bapa' | 'jadual_berkala';
  tajuk: string;
  mesej: string;
  tarikh: string;
  telahDibaca: boolean;
  muridId?: string;
  namaMurid?: string;
  konstrukId?: number;
}

export interface SoalanAktiviti {
  id: string;
  konstrukId: number;
  arahan: string;
  gambarUrl?: string;
  soalanTeks?: string;
  jawapanBetul: string[];
  pilihanItem: { id: string; teks: string; warna?: string }[];
  pembayang?: string;
}
