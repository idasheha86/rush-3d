/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Gamepad2,
  FileText,
  Archive,
  Bell,
  Trophy,
  Users,
  ChevronDown,
  RotateCcw,
  Sparkles,
  BookOpen,
  Volume2,
} from 'lucide-react';
import { Murid, RekodAktiviti, NotifikasiPeringatan } from './types';
import { MURID_AWAL, REKOD_ARKIB_AWAL, NOTIFIKASI_AWAL } from './data/initialData';
import { PapanPemukaAnalitik } from './components/PapanPemukaAnalitik';
import { AktivitiRiadahKeluarga } from './components/AktivitiRiadahKeluarga';
import { AktivitiSukuKata } from './components/AktivitiSukuKata';
import { AktivitiSusunAyat } from './components/AktivitiSusunAyat';
import { LaporanKemajuanIndividu } from './components/LaporanKemajuanIndividu';
import { ArkibDigital } from './components/ArkibDigital';
import { PusatNotifikasi } from './components/PusatNotifikasi';
import { SudutGamifikasi } from './components/SudutGamifikasi';
import { PWAInstallButton } from './components/PWAInstallButton';
import { OfflineIndicator } from './components/OfflineIndicator';
import { sounds } from './utils/soundEffects';

type TabNav = 'aktiviti' | 'analitik' | 'laporan' | 'arkib' | 'notifikasi' | 'ganjaran';
type SubAktiviti = 'riadah' | 'sukukata' | 'susunayat';

export default function App() {
  // State Data Tersimpan Setempat (Local Storage Persistence)
  const [senaraiMurid, setSenaraiMurid] = useState<Murid[]>(() => {
    const saved = localStorage.getItem('epemulihan_murid');
    return saved ? JSON.parse(saved) : MURID_AWAL;
  });

  const [senaraiRekod, setSenaraiRekod] = useState<RekodAktiviti[]>(() => {
    const saved = localStorage.getItem('epemulihan_arkib');
    return saved ? JSON.parse(saved) : REKOD_ARKIB_AWAL;
  });

  const [senaraiNotifikasi, setSenaraiNotifikasi] = useState<NotifikasiPeringatan[]>(() => {
    const saved = localStorage.getItem('epemulihan_notifikasi');
    return saved ? JSON.parse(saved) : NOTIFIKASI_AWAL;
  });

  const [idMuridAktif, setIdMuridAktif] = useState<string>(() => {
    return senaraiMurid[0]?.id || 'm1';
  });

  const [tabAktif, setTabAktif] = useState<TabNav>('aktiviti');
  const [subAktiviti, setSubAktiviti] = useState<SubAktiviti>('riadah');

  // Simpan data ke localStorage secara automatik
  useEffect(() => {
    localStorage.setItem('epemulihan_murid', JSON.stringify(senaraiMurid));
  }, [senaraiMurid]);

  useEffect(() => {
    localStorage.setItem('epemulihan_arkib', JSON.stringify(senaraiRekod));
  }, [senaraiRekod]);

  useEffect(() => {
    localStorage.setItem('epemulihan_notifikasi', JSON.stringify(senaraiNotifikasi));
  }, [senaraiNotifikasi]);

  const muridAktif = senaraiMurid.find((m) => m.id === idMuridAktif) || senaraiMurid[0];
  const notifikasiBelumBaca = senaraiNotifikasi.filter((n) => !n.telahDibaca).length;

  // Fungsi mengendalikan pencapaian aktiviti baharu
  const handleSimpanPencapaian = (rekod: RekodAktiviti, markahPeratus: number) => {
    // 1. Tambah rekod baharu ke arkib digital
    setSenaraiRekod((prev) => [rekod, ...prev]);

    // 2. Kemas kini status murid (bintang, status konstruk)
    setSenaraiMurid((prev) =>
      prev.map((m) => {
        if (m.id !== rekod.muridId) return m;

        const bintangTambahan = markahPeratus === 100 ? 5 : markahPeratus >= 50 ? 3 : 1;
        const konstrukLama = m.tahapKonstruk[rekod.konstrukId] || {
          status: 'BELUM',
          peratus: 0,
          tarikhSemakan: '',
        };

        const statusBaru = markahPeratus >= 80 ? 'MENGUASAI' : markahPeratus >= 50 ? 'SEDANG' : 'BELUM';
        const peratusTinggi = Math.max(konstrukLama.peratus, markahPeratus);

        // Semak lencana baharu
        const lencanaSet = new Set(m.lencana);
        if (markahPeratus === 100) lencanaSet.add('Bintang Cemerlang');
        if (rekod.konstrukId === 12 && markahPeratus >= 80) lencanaSet.add('Juara Membaca');
        if (rekod.konstrukId === 3 && markahPeratus >= 80) lencanaSet.add('Wira KV');

        return {
          ...m,
          bintang: m.bintang + bintangTambahan,
          lencana: Array.from(lencanaSet),
          tahapKonstruk: {
            ...m.tahapKonstruk,
            [rekod.konstrukId]: {
              status: statusBaru,
              peratus: peratusTinggi,
              tarikhSemakan: new Date().toISOString().split('T')[0],
              catatan: `Penilaian aktiviti terkini: ${markahPeratus}%.`,
            },
          },
        };
      })
    );

    // 3. Jana notifikasi pintar secara automatik
    if (markahPeratus < 50) {
      const notifAmaran: NotifikasiPeringatan = {
        id: `notif-${Date.now()}`,
        jenis: 'amaran_bimbingan',
        tajuk: `Perlu Bimbingan: ${muridAktif.nama.split(' ')[0]} (Konstruk ${rekod.konstrukId})`,
        mesej: `${muridAktif.nama} mendapat ${markahPeratus}% dalam ${rekod.tajukAktiviti}. Sila jadualkan sesi pengukuhan fasa bimbingan.`,
        tarikh: new Date().toLocaleDateString('ms-MY', { day: 'numeric', month: 'long', year: 'numeric' }),
        telahDibaca: false,
        muridId: muridAktif.id,
        namaMurid: muridAktif.nama,
        konstrukId: rekod.konstrukId,
      };
      setSenaraiNotifikasi((prev) => [notifAmaran, ...prev]);
    } else if (markahPeratus === 100) {
      const notifTahniah: NotifikasiPeringatan = {
        id: `notif-${Date.now()}`,
        jenis: 'kejayaan_lulus',
        tajuk: `Tahniah! Skor 100%: ${muridAktif.nama.split(' ')[0]}`,
        mesej: `${muridAktif.nama} berjaya menyelesaikan ${rekod.tajukAktiviti} dengan markah cemerlang 100%!`,
        tarikh: new Date().toLocaleDateString('ms-MY', { day: 'numeric', month: 'long', year: 'numeric' }),
        telahDibaca: false,
        muridId: muridAktif.id,
        namaMurid: muridAktif.nama,
        konstrukId: rekod.konstrukId,
      };
      setSenaraiNotifikasi((prev) => [notifTahniah, ...prev]);
    }
  };

  const handleTukarAvatar = (muridId: string, avatarBaru: string) => {
    setSenaraiMurid((prev) =>
      prev.map((m) => (m.id === muridId ? { ...m, avatarChibi: avatarBaru } : m))
    );
  };

  const handleKemaskiniCatatan = (muridId: string, catatanBaru: string) => {
    setSenaraiMurid((prev) =>
      prev.map((m) => (m.id === muridId ? { ...m, catatanGuru: catatanBaru } : m))
    );
  };

  const handleTambahMurid = (muridBaru: Murid) => {
    setSenaraiMurid((prev) => [muridBaru, ...prev]);
    setIdMuridAktif(muridBaru.id);
  };

  const handleSetSemulaData = () => {
    if (window.confirm('Adakah anda pasti mahu menetapkan semula data kepada data contoh asal KPM?')) {
      sounds.playPop();
      setSenaraiMurid(MURID_AWAL);
      setSenaraiRekod(REKOD_ARKIB_AWAL);
      setSenaraiNotifikasi(NOTIFIKASI_AWAL);
      setIdMuridAktif(MURID_AWAL[0].id);
      localStorage.clear();
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5] flex flex-col font-sans">
      {/* Bar Navigasi Atas (Header PWA) */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b-2 border-pink-100 shadow-xs no-print">
        <div className="max-w-6xl mx-auto px-3 sm:px-4 py-2.5 flex items-center justify-between gap-3">
          {/* Logo & Tajuk Aplikasi */}
          <div
            onClick={() => {
              sounds.playPop();
              setTabAktif('aktiviti');
            }}
            className="flex items-center gap-2.5 cursor-pointer select-none group"
          >
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-sky-200 via-pink-200 to-amber-200 border-2 border-pink-300 flex items-center justify-center text-xl shadow-xs group-hover:scale-105 transition">
              📖
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-sm sm:text-base font-black text-slate-900 tracking-tight leading-none">
                  e-Pemulihan Baca
                </h1>
                <span className="text-[10px] font-bold bg-pink-100 text-pink-700 px-1.5 py-0.2 rounded-md border border-pink-200">
                  Chibi
                </span>
              </div>
              <p className="text-[10px] text-slate-500 font-semibold leading-none mt-1">
                Kementerian Pendidikan Malaysia
              </p>
            </div>
          </div>

          {/* Pemilihan Murid Aktif & Pasang PWA */}
          <div className="flex items-center gap-2">
            {/* PWA Install Button */}
            <PWAInstallButton />

            {/* Pilihan Murid Aktif (Pantas di Telefon) */}
            <div className="relative">
              <select
                value={idMuridAktif}
                onChange={(e) => {
                  sounds.playPop();
                  setIdMuridAktif(e.target.value);
                }}
                className="appearance-none bg-sky-50/80 hover:bg-sky-100 border border-sky-200 text-sky-900 text-xs font-bold pl-7 pr-7 py-1.5 rounded-xl cursor-pointer focus:outline-none focus:ring-2 focus:ring-sky-300 transition"
              >
                {senaraiMurid.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.nama.split(' ')[0]} ({m.kelas})
                  </option>
                ))}
              </select>
              <div className="pointer-events-none absolute left-2 top-1/2 -translate-y-1/2 text-xs">
                {muridAktif.avatarChibi === 'kancil'
                  ? '🦌'
                  : muridAktif.avatarChibi === 'kucing'
                  ? '🐱'
                  : muridAktif.avatarChibi === 'arnab'
                  ? '🐰'
                  : '🐻'}
              </div>
              <ChevronDown className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-sky-600" />
            </div>

            {/* Bintang Murid */}
            <div
              onClick={() => {
                sounds.playPop();
                setTabAktif('ganjaran');
              }}
              className="flex items-center gap-1 bg-amber-50 border border-amber-200 px-2.5 py-1.5 rounded-xl text-xs font-bold text-amber-800 cursor-pointer hover:bg-amber-100 transition"
              title="Lihat sudut ganjaran dan lencana"
            >
              <span className="text-amber-500">⭐</span>
              <span>{muridAktif.bintang}</span>
            </div>
          </div>
        </div>

        {/* Bar Navigasi Tab (Sangat Mesra Telefon & Sentuhan Jari) */}
        <div className="max-w-6xl mx-auto px-2 overflow-x-auto scrollbar-none flex gap-1 py-1 border-t border-slate-100">
          {[
            { id: 'aktiviti', label: 'Aktiviti Membaca', ikon: <Gamepad2 className="w-4 h-4" /> },
            { id: 'analitik', label: 'Papan Pemuka', ikon: <LayoutDashboard className="w-4 h-4" /> },
            { id: 'laporan', label: 'Laporan Individu', ikon: <FileText className="w-4 h-4" /> },
            { id: 'arkib', label: 'Arkib Digital', ikon: <Archive className="w-4 h-4" /> },
            {
              id: 'notifikasi',
              label: 'Notifikasi',
              ikon: <Bell className="w-4 h-4" />,
              badge: notifikasiBelumBaca > 0 ? notifikasiBelumBaca : undefined,
            },
            { id: 'ganjaran', label: 'Ganjaran Chibi', ikon: <Trophy className="w-4 h-4" /> },
          ].map((tab) => {
            const isActive = tabAktif === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  sounds.playPop();
                  setTabAktif(tab.id as TabNav);
                }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all duration-150 select-none ${
                  isActive
                    ? 'bg-gradient-to-r from-pink-400 to-rose-400 text-white shadow-xs scale-102'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
                }`}
              >
                {tab.ikon}
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className="ml-0.5 px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-white text-pink-600 shadow-xs">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </header>

      {/* Kandungan Utama Berdasarkan Tab */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-3 sm:p-5">
        {/* Tab 1: Aktiviti Membaca */}
        {tabAktif === 'aktiviti' && (
          <div className="space-y-4">
            {/* Pilihan Sub-Aktiviti Membaca */}
            <div className="flex flex-wrap items-center justify-between gap-2 bg-white/80 p-3 rounded-2xl border-2 border-slate-200/80 shadow-xs">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider mr-1">
                  Pilih Mod Aktiviti:
                </span>
                <button
                  onClick={() => {
                    sounds.playPop();
                    setSubAktiviti('riadah');
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                    subAktiviti === 'riadah'
                      ? 'bg-emerald-500 text-white shadow-xs'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  🚀 Aktiviti 3 (Lembaran KPM)
                </button>

                <button
                  onClick={() => {
                    sounds.playPop();
                    setSubAktiviti('sukukata');
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                    subAktiviti === 'sukukata'
                      ? 'bg-sky-500 text-white shadow-xs'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  🧩 Cantum Suku Kata
                </button>

                <button
                  onClick={() => {
                    sounds.playPop();
                    setSubAktiviti('susunayat');
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                    subAktiviti === 'susunayat'
                      ? 'bg-purple-500 text-white shadow-xs'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  📖 Susun Ayat Mudah
                </button>
              </div>

              <div className="text-xs text-slate-500 font-medium">
                Format: <strong>Seret & Lepas (Drag & Drop)</strong> / <strong>Tekan & Letak</strong>
              </div>
            </div>

            {/* Sub-Aktiviti 1: Lembaran Modul Riadah Keluarga (Berdasarkan Imej Pengguna) */}
            {subAktiviti === 'riadah' && (
              <AktivitiRiadahKeluarga
                muridAktif={muridAktif}
                onSimpanPencapaian={handleSimpanPencapaian}
              />
            )}

            {/* Sub-Aktiviti 2: Cantum Suku Kata */}
            {subAktiviti === 'sukukata' && (
              <AktivitiSukuKata
                muridAktif={muridAktif}
                onSimpanPencapaian={handleSimpanPencapaian}
              />
            )}

            {/* Sub-Aktiviti 3: Susun Ayat */}
            {subAktiviti === 'susunayat' && (
              <AktivitiSusunAyat
                muridAktif={muridAktif}
                onSimpanPencapaian={handleSimpanPencapaian}
              />
            )}
          </div>
        )}

        {/* Tab 2: Papan Pemuka Analitik Guru */}
        {tabAktif === 'analitik' && (
          <PapanPemukaAnalitik
            senaraiMurid={senaraiMurid}
            onPilihMurid={(m) => {
              setIdMuridAktif(m.id);
            }}
            onBukaLaporan={(m) => {
              setIdMuridAktif(m.id);
              setTabAktif('laporan');
            }}
            onMulaAktiviti={(m) => {
              setIdMuridAktif(m.id);
              setTabAktif('aktiviti');
            }}
            onTambahMurid={handleTambahMurid}
          />
        )}

        {/* Tab 3: Laporan Kemajuan Individu Masa Nyata */}
        {tabAktif === 'laporan' && (
          <LaporanKemajuanIndividu
            murid={muridAktif}
            senaraiRekod={senaraiRekod}
            onKemaskiniCatatan={handleKemaskiniCatatan}
            onKembali={() => setTabAktif('analitik')}
          />
        )}

        {/* Tab 4: Arkib Digital Sejarah Pembelajaran */}
        {tabAktif === 'arkib' && <ArkibDigital senaraiRekod={senaraiRekod} />}

        {/* Tab 5: Pusat Notifikasi Pintar */}
        {tabAktif === 'notifikasi' && (
          <PusatNotifikasi
            senaraiNotifikasi={senaraiNotifikasi}
            senaraiMurid={senaraiMurid}
            onTandaDibaca={(id) => {
              setSenaraiNotifikasi((prev) =>
                prev.map((n) => (n.id === id ? { ...n, telahDibaca: true } : n))
              );
            }}
            onTandaSemuaDibaca={() => {
              setSenaraiNotifikasi((prev) =>
                prev.map((n) => ({ ...n, telahDibaca: true }))
              );
            }}
            onPadamNotifikasi={(id) => {
              setSenaraiNotifikasi((prev) => prev.filter((n) => n.id !== id));
            }}
            onTambahPeringatan={(notif) => {
              setSenaraiNotifikasi((prev) => [notif, ...prev]);
            }}
          />
        )}

        {/* Tab 6: Sudut Gamifikasi Chibi */}
        {tabAktif === 'ganjaran' && (
          <SudutGamifikasi
            murid={muridAktif}
            onTukarAvatar={handleTukarAvatar}
          />
        )}
      </main>

      {/* Footer Mesra Guru Pemulihan Khas */}
      <footer className="no-print mt-auto border-t border-slate-200 bg-white/70 py-4 text-center text-xs text-slate-500">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>
            e-Pemulihan Baca Chibi © 2026 • Program Pemulihan Khas Kementerian Pendidikan Malaysia
          </p>
          <button
            onClick={handleSetSemulaData}
            className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-slate-600 transition"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Set Semula Data Contoh</span>
          </button>
        </div>
      </footer>

      {/* Penunjuk Mod Luar Talian PWA */}
      <OfflineIndicator />
    </div>
  );
}
