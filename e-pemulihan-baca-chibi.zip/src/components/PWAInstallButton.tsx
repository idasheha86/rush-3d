import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Sparkles, X, Smartphone } from 'lucide-react';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  if (isInstallable) {
    return (
      <button
        onClick={install}
        className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-sky-400 to-indigo-400 px-3.5 py-1.5 text-xs md:text-sm font-semibold text-white shadow-md hover:shadow-lg hover:from-sky-500 hover:to-indigo-500 transition-all transform active:scale-95"
        title="Pasang aplikasi ke telefon pintar anda"
      >
        <Download className="w-4 h-4 text-white" />
        <span>Pasang Aplikasi PWA</span>
        <Sparkles className="w-3.5 h-3.5 text-yellow-200" />
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center gap-1.5 rounded-xl border border-sky-300 bg-sky-50/80 px-3 py-1.5 text-xs font-semibold text-sky-800 hover:bg-sky-100 transition"
        >
          <Smartphone className="w-3.5 h-3.5 text-sky-600" />
          <span>Pasang di iPhone/iPad</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4">
            <div className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl border-2 border-pink-100 animate-in fade-in zoom-in duration-200">
              <div className="flex justify-between items-center mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-pink-100 flex items-center justify-center text-pink-600 font-bold">
                    📱
                  </div>
                  <h3 className="text-base font-bold text-slate-800">Pasang di iPhone / iPad</h3>
                </div>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="rounded-full p-1 text-slate-400 hover:bg-slate-100"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed space-y-2">
                <span className="block font-medium">Ikuti dua langkah mudah ini:</span>
                <span className="block bg-sky-50 p-2.5 rounded-xl border border-sky-100">
                  1. Tekan butang <strong>Kongsi (Share)</strong> pada bar pelayar Safari.
                </span>
                <span className="block bg-pink-50 p-2.5 rounded-xl border border-pink-100">
                  2. Tatal ke bawah dan pilih <strong>"Tambah ke Skrin Utama" (Add to Home Screen)</strong>.
                </span>
              </p>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-4 w-full rounded-xl bg-pink-400 hover:bg-pink-500 py-2.5 text-xs font-bold text-white shadow-sm transition"
              >
                Faham, Tutup
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
