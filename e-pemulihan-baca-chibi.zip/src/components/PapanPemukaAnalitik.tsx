import React, { useState } from 'react';
import {
  Users,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  TrendingUp,
  FileText,
  Star,
  Award,
  Filter,
  Plus,
  PlayCircle,
  UserCheck,
  Search,
} from 'lucide-react';
import { Murid, StatusPenguasaan } from '../types';
import { SENARAI_KONSTRUK_KPM } from '../data/kpmKonstruk';
import { sounds } from '../utils/soundEffects';

interface PapanPemukaProps {
  senaraiMurid: Murid[];
  onPilihMurid: (murid: Murid) => void;
  onBukaLaporan: (murid: Murid) => void;
  onMulaAktiviti: (murid: Murid) => void;
  onTambahMurid: (muridBaru: Murid) => void;
}

export const PapanPemukaAnalitik: React.FC<PapanPemukaProps> = ({
  senaraiMurid,
  onPilihMurid,
  onBukaLaporan,
  onMulaAktiviti,
  onTambahMurid,
}) => {
  const [tapisTahun, setTapisTahun] = useState<string>('Semua');
  const [carian, setCarian] = useState('');
  const [tunjukBorangTambah, setTunjukBorangTambah] = useState(false);

  // Borang Tambah Murid Baharu
  const [namaBaru, setNamaBaru] = useState('');
  const [myKidBaru, setMyKidBaru] = useState('');
  const [jantinaBaru, setJantinaBaru] = useState<'Lelaki' | 'Perempuan'>('Lelaki');
  const [tahunBaru, setTahunBaru] = useState<'Tahun 1' | 'Tahun 2' | 'Tahun 3'>('Tahun 2');
  const [kelasBaru, setKelasBaru] = useState('2 Amanah');
  const [penjagaBaru, setPenjagaBaru] = useState('');
  const [telBaru, setTelBaru] = useState('');

  // Kiraan Analitik Keseluruhan
  const jumlahMurid = senaraiMurid.length;

  // Kira murid yang telah menguasai minimum 8 konstruk
  const muridMenguasai = senaraiMurid.filter((m) => {
    const kiraMenguasai = Object.values(m.tahapKonstruk).filter(
      (k) => k.status === 'MENGUASAI'
    ).length;
    return kiraMenguasai >= 8;
  }).length;

  const muridSedang = senaraiMurid.filter((m) => {
    const kiraMenguasai = Object.values(m.tahapKonstruk).filter(
      (k) => k.status === 'MENGUASAI'
    ).length;
    return kiraMenguasai >= 4 && kiraMenguasai < 8;
  }).length;

  const muridPerluBimbingan = jumlahMurid - (muridMenguasai + muridSedang);

  // Purata Penguasaan Setiap Konstruk
  const purataKonstruk = SENARAI_KONSTRUK_KPM.map((kon) => {
    const jumlahPeratus = senaraiMurid.reduce((acc, curr) => {
      return acc + (curr.tahapKonstruk[kon.id]?.peratus || 0);
    }, 0);
    const purata = jumlahMurid > 0 ? Math.round(jumlahPeratus / jumlahMurid) : 0;
    return {
      ...kon,
      purata,
    };
  });

  // Tapis Senarai
  const muridDitapis = senaraiMurid.filter((m) => {
    const padanTahun = tapisTahun === 'Semua' || m.tahun === tapisTahun;
    const padanCari =
      m.nama.toLowerCase().includes(carian.toLowerCase()) ||
      m.kelas.toLowerCase().includes(carian.toLowerCase()) ||
      m.noMyKid.includes(carian);
    return padanTahun && padanCari;
  });

  const handleHantarTambahMurid = (e: React.FormEvent) => {
    e.preventDefault();
    if (!namaBaru.trim()) return;

    sounds.playCorrect();

    // Default status konstruk awal
    const tahapAwal: Record<number, { status: StatusPenguasaan; peratus: number; tarikhSemakan: string }> = {};
    for (let i = 1; i <= 12; i++) {
      tahapAwal[i] = {
        status: i === 1 ? 'MENGUASAI' : 'BELUM',
        peratus: i === 1 ? 80 : 0,
        tarikhSemakan: new Date().toISOString().split('T')[0],
      };
    }

    const muridBaruData: Murid = {
      id: `m-${Date.now()}`,
      nama: namaBaru.trim(),
      noMyKid: myKidBaru.trim() || '170000-00-0000',
      jantina: jantinaBaru,
      tahun: tahunBaru,
      kelas: kelasBaru,
      namaPenjaga: penjagaBaru.trim() || 'Penjaga',
      noTelPenjaga: telBaru.trim() || '012-0000000',
      avatarChibi: 'kancil',
      bintang: 5,
      lencana: ['Bintang Abjad'],
      tahapKonstruk: tahapAwal,
      catatanGuru: 'Murid baru didaftarkan ke Program Pemulihan Khas.',
      tarikhDaftar: new Date().toISOString().split('T')[0],
    };

    onTambahMurid(muridBaruData);
    setTunjukBorangTambah(false);
    setNamaBaru('');
    setMyKidBaru('');
    setPenjagaBaru('');
    setTelBaru('');
  };

  return (
    <div className="space-y-6">
      {/* Tajuk Papan Pemuka */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-slate-800 flex items-center gap-2">
            <span>Papan Pemuka Analitik Pemulihan Khas</span>
            <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2.5 py-1 rounded-full border border-emerald-200">
              KPM Malaysia
            </span>
          </h2>
          <p className="text-xs md:text-sm text-slate-500 mt-0.5">
            Pengesanan data pencapaian 12 Konstruk Literasi murid secara automatik dan masa nyata.
          </p>
        </div>

        <button
          onClick={() => {
            sounds.playPop();
            setTunjukBorangTambah(!tunjukBorangTambah);
          }}
          className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs md:text-sm font-bold text-white bg-gradient-to-r from-pink-400 to-rose-400 hover:from-pink-500 hover:to-rose-500 shadow-sm transition active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>Daftar Murid Baharu</span>
        </button>
      </div>

      {/* Kad Statistik Analitik (Pastel Themes) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        {/* Kad 1: Jumlah Murid */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-sky-50 to-blue-50 border-2 border-sky-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-sky-800">Jumlah Murid</span>
            <Users className="w-4 h-4 text-sky-600" />
          </div>
          <div className="text-2xl md:text-3xl font-extrabold text-sky-900 mt-2">
            {jumlahMurid} <span className="text-xs font-normal text-sky-600">orang</span>
          </div>
          <div className="text-[11px] text-sky-600 mt-1">
            Program Pemulihan Khas
          </div>
        </div>

        {/* Kad 2: Telah Menguasai (Sedia Arus Perdana) */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50 border-2 border-emerald-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-800">Telah Menguasai</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl md:text-3xl font-extrabold text-emerald-900 mt-2">
            {muridMenguasai} <span className="text-xs font-normal text-emerald-600">orang</span>
          </div>
          <div className="text-[11px] text-emerald-600 mt-1">
            Layak Pelepasan / Arus Perdana
          </div>
        </div>

        {/* Kad 3: Sedang Menguasai */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-50 to-orange-50 border-2 border-amber-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-800">Sedang Menguasai</span>
            <TrendingUp className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl md:text-3xl font-extrabold text-amber-900 mt-2">
            {muridSedang} <span className="text-xs font-normal text-amber-600">orang</span>
          </div>
          <div className="text-[11px] text-amber-600 mt-1">
            Bimbingan Tahap Pertengahan
          </div>
        </div>

        {/* Kad 4: Perlu Intervensi Khas */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-pink-50 to-rose-50 border-2 border-pink-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-pink-800">Perlu Bimbingan</span>
            <AlertCircle className="w-4 h-4 text-pink-600" />
          </div>
          <div className="text-2xl md:text-3xl font-extrabold text-pink-900 mt-2">
            {muridPerluBimbingan} <span className="text-xs font-normal text-pink-600">orang</span>
          </div>
          <div className="text-[11px] text-pink-600 mt-1">
            Intervensi K1 - K4 Diperlukan
          </div>
        </div>
      </div>

      {/* Borang Tambah Murid (Jika Terbuka) */}
      {tunjukBorangTambah && (
        <form
          onSubmit={handleHantarTambahMurid}
          className="bg-white p-5 rounded-2xl border-2 border-pink-300 shadow-md space-y-4 animate-in fade-in duration-200"
        >
          <div className="flex items-center justify-between border-b pb-2">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-pink-500" />
              <span>Daftar Maklumat Murid Pemulihan Khas</span>
            </h3>
            <button
              type="button"
              onClick={() => setTunjukBorangTambah(false)}
              className="text-xs text-slate-400 hover:text-slate-600"
            >
              Batal
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Nama Penuh Murid:
              </label>
              <input
                type="text"
                required
                value={namaBaru}
                onChange={(e) => setNamaBaru(e.target.value)}
                placeholder="Contoh: Nurul Hana binti Amran"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-pink-300"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                No. Kad Pengenalan / MyKid:
              </label>
              <input
                type="text"
                value={myKidBaru}
                onChange={(e) => setMyKidBaru(e.target.value)}
                placeholder="Contoh: 170912-10-5678"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-pink-300"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Jantina:
              </label>
              <select
                value={jantinaBaru}
                onChange={(e) => setJantinaBaru(e.target.value as 'Lelaki' | 'Perempuan')}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-pink-300 bg-white"
              >
                <option value="Lelaki">Lelaki</option>
                <option value="Perempuan">Perempuan</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Tahun Persekolahan:
              </label>
              <select
                value={tahunBaru}
                onChange={(e) => setTahunBaru(e.target.value as 'Tahun 1' | 'Tahun 2' | 'Tahun 3')}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-pink-300 bg-white"
              >
                <option value="Tahun 1">Tahun 1</option>
                <option value="Tahun 2">Tahun 2</option>
                <option value="Tahun 3">Tahun 3</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Nama Kelas:
              </label>
              <input
                type="text"
                value={kelasBaru}
                onChange={(e) => setKelasBaru(e.target.value)}
                placeholder="Contoh: 2 Amanah"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-pink-300"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Nama Ibu Bapa / Penjaga:
              </label>
              <input
                type="text"
                value={penjagaBaru}
                onChange={(e) => setPenjagaBaru(e.target.value)}
                placeholder="Contoh: Puan Rohana"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-pink-300"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setTunjukBorangTambah(false)}
              className="px-4 py-2 rounded-xl font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 text-xs"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl font-bold text-white bg-pink-500 hover:bg-pink-600 text-xs shadow-sm"
            >
              Simpan Maklumat Murid
            </button>
          </div>
        </form>
      )}

      {/* Analisis Visual Taburan 12 Konstruk Literasi KPM */}
      <div className="bg-white p-5 rounded-2xl border-2 border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between border-b pb-2">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-indigo-500" />
            <h3 className="text-sm md:text-base font-bold text-slate-800">
              Purata Penguasaan Kelas Mengikut 12 Konstruk Literasi
            </h3>
          </div>
          <span className="text-[11px] text-slate-400">
            Penilaian Sukatan Pemulihan Khas KPM
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5 pt-1">
          {purataKonstruk.map((item) => {
            const warnaBar =
              item.purata >= 80
                ? 'bg-emerald-400'
                : item.purata >= 50
                ? 'bg-amber-400'
                : 'bg-rose-300';

            return (
              <div
                key={item.id}
                className="p-3 rounded-xl border border-slate-200/80 bg-slate-50/50 hover:bg-slate-50 transition"
              >
                <div className="flex items-center justify-between text-xs font-bold mb-1">
                  <span className="text-indigo-700">{item.kod}</span>
                  <span className="text-slate-700">{item.purata}%</span>
                </div>
                {/* Progress Bar */}
                <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden mb-1.5">
                  <div
                    className={`h-full ${warnaBar} transition-all duration-500`}
                    style={{ width: `${item.purata}%` }}
                  />
                </div>
                <p className="text-[10px] text-slate-500 line-clamp-1" title={item.tajuk}>
                  {item.tajuk.replace('Keupayaan Membaca ', '')}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Senarai Murid & Penapis */}
      <div className="bg-white p-5 rounded-2xl border-2 border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-sky-600" />
            <h3 className="text-sm md:text-base font-bold text-slate-800">
              Senarai Murid Pemulihan Khas
            </h3>
            <span className="text-xs bg-slate-100 text-slate-600 font-semibold px-2 py-0.5 rounded-full">
              {muridDitapis.length} murid
            </span>
          </div>

          {/* Carian & Penapis Tahun */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari murid / kelas / MyKid..."
                value={carian}
                onChange={(e) => setCarian(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-300 w-48 md:w-56"
              />
            </div>

            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
              {['Semua', 'Tahun 1', 'Tahun 2', 'Tahun 3'].map((thn) => (
                <button
                  key={thn}
                  onClick={() => {
                    sounds.playPop();
                    setTapisTahun(thn);
                  }}
                  className={`px-2.5 py-1 rounded-lg transition ${
                    tapisTahun === thn
                      ? 'bg-white text-sky-700 shadow-xs font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {thn}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Jadual / Kad Murid */}
        <div className="space-y-3">
          {muridDitapis.map((murid) => {
            const jumlahKonstrukMenguasai = Object.values(murid.tahapKonstruk).filter(
              (k) => k.status === 'MENGUASAI'
            ).length;

            const peratusKeseluruhan = Math.round(
              (jumlahKonstrukMenguasai / 12) * 100
            );

            const badgeStatus =
              jumlahKonstrukMenguasai >= 8 ? (
                <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Menguasai (Sedia Pelepasan)</span>
                </span>
              ) : jumlahKonstrukMenguasai >= 4 ? (
                <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 border border-amber-200 flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>Sedang Berkembang</span>
                </span>
              ) : (
                <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-rose-100 text-rose-800 border border-rose-200 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>Perlu Bimbingan Khas</span>
                </span>
              );

            return (
              <div
                key={murid.id}
                className="p-4 rounded-2xl border-2 border-slate-100 hover:border-sky-200 bg-white hover:bg-sky-50/20 transition-all shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  {/* Avatar Chibi Murid */}
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-pink-100 to-sky-100 border-2 border-pink-200 flex items-center justify-center text-2xl shrink-0 shadow-inner">
                    {murid.avatarChibi === 'kancil'
                      ? '🦌'
                      : murid.avatarChibi === 'kucing'
                      ? '🐱'
                      : murid.avatarChibi === 'arnab'
                      ? '🐰'
                      : '🐻'}
                  </div>

                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="text-sm md:text-base font-bold text-slate-800 truncate">
                        {murid.nama}
                      </h4>
                      {badgeStatus}
                    </div>

                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mt-1">
                      <span>Kelas: <strong>{murid.kelas}</strong></span>
                      <span>•</span>
                      <span>MyKid: <strong>{murid.noMyKid}</strong></span>
                      <span>•</span>
                      <span className="flex items-center gap-1 text-amber-600 font-bold">
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                        <span>{murid.bintang} bintang</span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Kemajuan & Tindakan */}
                <div className="flex items-center justify-between md:justify-end gap-3 pt-2 md:pt-0 border-t md:border-t-0 border-slate-100">
                  {/* Bar Ringkas 12 Konstruk */}
                  <div className="text-right">
                    <div className="text-xs font-bold text-slate-700">
                      {jumlahKonstrukMenguasai} / 12 Konstruk
                    </div>
                    <div className="w-24 md:w-32 bg-slate-200 rounded-full h-2 overflow-hidden mt-1">
                      <div
                        className="bg-indigo-500 h-full rounded-full"
                        style={{ width: `${peratusKeseluruhan}%` }}
                      />
                    </div>
                  </div>

                  {/* Butang Tindakan */}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        sounds.playPop();
                        onMulaAktiviti(murid);
                      }}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 shadow-xs transition active:scale-95"
                      title="Mula aktiviti membaca"
                    >
                      <PlayCircle className="w-3.5 h-3.5" />
                      <span>Uji / Latih</span>
                    </button>

                    <button
                      onClick={() => {
                        sounds.playPop();
                        onBukaLaporan(murid);
                      }}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 transition"
                      title="Lihat slip laporan kemajuan individu"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>Laporan</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
