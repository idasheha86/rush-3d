import React, { useState } from 'react';
import { Volume2, CheckCircle2, RotateCcw, Sparkles, ChevronRight, Trophy } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../utils/soundEffects';
import { ChibiMascot } from './ChibiMascot';
import { Murid, RekodAktiviti } from '../types';

interface AktivitiSukuKataProps {
  muridAktif: Murid;
  onSimpanPencapaian: (rekod: RekodAktiviti, markahPeratus: number) => void;
}

interface SoalanKV {
  id: string;
  konstrukId: number;
  perkataanPenuh: string;
  suku1: string;
  suku2: string;
  gambarIkon: string;
  pilihanSuku: string[];
  maksud: string;
}

const SENARAI_SOALAN: SoalanKV[] = [
  {
    id: 'kv-1',
    konstrukId: 3,
    perkataanPenuh: 'buku',
    suku1: 'bu',
    suku2: 'ku',
    gambarIkon: '📚',
    pilihanSuku: ['bu', 'ku', 'ca', 'ba'],
    maksud: 'Bahan bacaan berfaedah untuk menambah ilmu',
  },
  {
    id: 'kv-2',
    konstrukId: 3,
    perkataanPenuh: 'bola',
    suku1: 'bo',
    suku2: 'la',
    gambarIkon: '⚽',
    pilihanSuku: ['bo', 'la', 'to', 'ma'],
    maksud: 'Alat permainan bulat disepak di padang',
  },
  {
    id: 'kv-3',
    konstrukId: 7,
    perkataanPenuh: 'cawan',
    suku1: 'ca',
    suku2: 'wan',
    gambarIkon: '🍵',
    pilihanSuku: ['ca', 'wan', 'man', 'ku'],
    maksud: 'Bekas untuk minum air kopi atau teh panas',
  },
  {
    id: 'kv-4',
    konstrukId: 7,
    perkataanPenuh: 'rumah',
    suku1: 'ru',
    suku2: 'mah',
    gambarIkon: '🏡',
    pilihanSuku: ['ru', 'mah', 'sah', 'ba'],
    maksud: 'Tempat tinggal yang selesa dan selamat bersama keluarga',
  },
  {
    id: 'kv-5',
    konstrukId: 7,
    perkataanPenuh: 'gajah',
    suku1: 'ga',
    suku2: 'jah',
    gambarIkon: '🐘',
    pilihanSuku: ['ga', 'jah', 'lah', 'ka'],
    maksud: 'Haiwan darat yang besar dan mempunyai belalai panjang',
  },
];

export const AktivitiSukuKata: React.FC<AktivitiSukuKataProps> = ({
  muridAktif,
  onSimpanPencapaian,
}) => {
  const [indexSoalan, setIndexSoalan] = useState(0);
  const [jawapanSlot, setJawapanSlot] = useState<(string | null)[]>([null, null]);
  const [selectedSuku, setSelectedSuku] = useState<string | null>(null);
  const [telahDisemak, setTelahDisemak] = useState(false);
  const [adakahBetul, setAdakahBetul] = useState<boolean | null>(null);
  const [jumlahBetul, setJumlahBetul] = useState(0);
  const [selesaiSemua, setSelesaiSemua] = useState(false);
  const [pesananMascot, setPesananMascot] = useState('Tarik atau tekan kad suku kata untuk mencantumkan perkataan bergambar.');

  const soalanSemasa = SENARAI_SOALAN[indexSoalan];

  const handlePilihSuku = (suku: string) => {
    sounds.playPop();
    sounds.sebutPerkataan(suku);
    setSelectedSuku(suku === selectedSuku ? null : suku);
    setPesananMascot(`Bagus! Letakkan suku kata "${suku}" ke petak yang betul.`);
  };

  const handleTekanSlot = (slotIndex: number) => {
    if (telahDisemak) return;

    if (selectedSuku) {
      sounds.playPop();
      const updated = [...jawapanSlot];
      updated[slotIndex] = selectedSuku;
      setJawapanSlot(updated);
      setSelectedSuku(null);
    } else if (jawapanSlot[slotIndex]) {
      sounds.playPop();
      const updated = [...jawapanSlot];
      updated[slotIndex] = null;
      setJawapanSlot(updated);
    }
  };

  // Drag and drop
  const handleDragStart = (e: React.DragEvent, suku: string) => {
    e.dataTransfer.setData('text/plain', suku);
    sounds.playPop();
  };

  const handleDrop = (e: React.DragEvent, slotIndex: number) => {
    e.preventDefault();
    if (telahDisemak) return;
    const suku = e.dataTransfer.getData('text/plain');
    if (suku) {
      sounds.playCorrect();
      const updated = [...jawapanSlot];
      updated[slotIndex] = suku;
      setJawapanSlot(updated);
      setSelectedSuku(null);
    }
  };

  const handleSemak = () => {
    const cantuman = (jawapanSlot[0] || '') + (jawapanSlot[1] || '');
    const betul = cantuman.toLowerCase() === soalanSemasa.perkataanPenuh.toLowerCase();

    setTelahDisemak(true);
    setAdakahBetul(betul);

    if (betul) {
      sounds.playCorrect();
      sounds.playStarChime();
      sounds.sebutPerkataan(soalanSemasa.perkataanPenuh);
      setJumlahBetul(prev => prev + 1);
      setPesananMascot(`Syabas adik! Cantuman betul: "${soalanSemasa.perkataanPenuh}"!`);
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#38BDF8', '#F472B6', '#34D399', '#FBBF24'],
      });
    } else {
      sounds.playTryAgain();
      setPesananMascot(`Kurang tepat sedikit. Jawapan betul ialah "${soalanSemasa.suku1}" + "${soalanSemasa.suku2}".`);
    }
  };

  const handleSeterusnya = () => {
    sounds.playPop();
    if (indexSoalan < SENARAI_SOALAN.length - 1) {
      setIndexSoalan(prev => prev + 1);
      setJawapanSlot([null, null]);
      setSelectedSuku(null);
      setTelahDisemak(false);
      setAdakahBetul(null);
      setPesananMascot('Hebat! Mari kita teruskan ke soalan suku kata yang seterusnya.');
    } else {
      // Selesai semua
      const totalSkor = Math.round(((jumlahBetul + (adakahBetul ? 1 : 0)) / SENARAI_SOALAN.length) * 100);
      setSelesaiSemua(true);

      const rekod: RekodAktiviti = {
        id: `rk-${Date.now()}`,
        muridId: muridAktif.id,
        namaMurid: muridAktif.nama,
        konstrukId: 3,
        tajukAktiviti: 'Aktiviti Cantum Suku Kata Bergambar',
        tarikh: new Date().toLocaleDateString('ms-MY', {
          day: 'numeric',
          month: 'long',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        }),
        markah: totalSkor,
        bilanganBetul: jumlahBetul + (adakahBetul ? 1 : 0),
        jumlahSoalan: SENARAI_SOALAN.length,
        tempohMasaSaat: 60,
        status: totalSkor >= 80 ? 'MENGUASAI' : totalSkor >= 50 ? 'SEDANG' : 'BELUM',
        jenisInteraksi: 'Seret & Lepas',
      };

      onSimpanPencapaian(rekod, totalSkor);
    }
  };

  const handleMulaSemula = () => {
    sounds.playPop();
    setIndexSoalan(0);
    setJawapanSlot([null, null]);
    setSelectedSuku(null);
    setTelahDisemak(false);
    setAdakahBetul(null);
    setJumlahBetul(0);
    setSelesaiSemua(false);
    setPesananMascot('Tarik atau tekan kad suku kata untuk mencantumkan perkataan bergambar.');
  };

  if (selesaiSemua) {
    const markahAkhir = Math.round((jumlahBetul / SENARAI_SOALAN.length) * 100);
    return (
      <div className="bg-white p-6 rounded-3xl border-2 border-pink-200 text-center space-y-4 shadow-sm">
        <div className="w-16 h-16 mx-auto rounded-full bg-pink-100 flex items-center justify-center text-3xl">
          🌟
        </div>
        <h3 className="text-xl font-bold text-slate-800">
          Tahniah! Modul Suku Kata Selesai
        </h3>
        <p className="text-sm text-slate-600">
          {muridAktif.nama} mendapat markah <strong>{markahAkhir}%</strong> ({jumlahBetul} daripada {SENARAI_SOALAN.length} soalan betul).
        </p>

        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold max-w-sm mx-auto">
          Pencapaian telah direkodkan ke dalam Arkib Digital dan Papan Pemuka Analitik Guru.
        </div>

        <button
          onClick={handleMulaSemula}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs md:text-sm text-white bg-gradient-to-r from-sky-400 to-indigo-400 hover:from-sky-500 hover:to-indigo-500 shadow-md transition"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Ulang Semula Modul</span>
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header Aktiviti Suku Kata */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-white/90 p-4 rounded-2xl border-2 border-sky-100 shadow-sm">
        <div>
          <span className="text-xs font-bold text-sky-700 bg-sky-100 px-2.5 py-0.5 rounded-full">
            Konstruk 3 & 7 (KV+KV & KV+KVK)
          </span>
          <h2 className="text-base md:text-lg font-bold text-slate-800 mt-1">
            Cantumkan Suku Kata Menjadi Perkataan
          </h2>
          <p className="text-xs text-slate-500">
            Soalan {indexSoalan + 1} daripada {SENARAI_SOALAN.length}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-pink-50 text-pink-700 border border-pink-200">
            Betul: {jumlahBetul} / {SENARAI_SOALAN.length}
          </span>
          <button
            onClick={handleMulaSemula}
            className="p-2 text-slate-500 hover:bg-slate-100 rounded-xl transition"
            title="Set semula"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Maskot Chibi */}
      <ChibiMascot
        pesanan={pesananMascot}
        expression={adakahBetul ? 'cheer' : 'happy'}
        namaMascot="Adik Dania Chibi"
      />

      {/* Kad Soalan Utama Bergambar */}
      <div className="bg-gradient-to-b from-white to-pink-50/30 p-6 rounded-3xl border-2 border-pink-100 shadow-xs text-center space-y-4">
        {/* Gambar Ikon Objek Chibi */}
        <div className="relative inline-block">
          <div className="w-28 h-28 mx-auto rounded-3xl bg-pink-50 border-4 border-pink-200/80 flex items-center justify-center text-6xl shadow-inner animate-pulse">
            {soalanSemasa.gambarIkon}
          </div>
          <button
            onClick={() => sounds.sebutPerkataan(soalanSemasa.perkataanPenuh)}
            className="absolute -bottom-2 -right-2 p-2 bg-white rounded-full shadow-md text-pink-500 hover:bg-pink-50 transition border border-pink-200"
            title="Dengar bunyi perkataan"
          >
            <Volume2 className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-slate-500 italic max-w-xs mx-auto">
          "{soalanSemasa.maksud}"
        </p>

        {/* Petak Cantuman Dua Suku Kata (Drop Target) */}
        <div className="flex justify-center items-center gap-3 pt-2">
          {[0, 1].map((slotIdx) => {
            const sukuVal = jawapanSlot[slotIdx];
            return (
              <div
                key={slotIdx}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => handleDrop(e, slotIdx)}
                onClick={() => handleTekanSlot(slotIdx)}
                className={`w-24 h-20 md:w-28 md:h-24 rounded-2xl border-3 flex flex-col items-center justify-center cursor-pointer transition-all ${
                  telahDisemak && adakahBetul
                    ? 'bg-emerald-50 border-emerald-400 text-emerald-800'
                    : telahDisemak && !adakahBetul
                    ? 'bg-rose-50 border-rose-400 text-rose-800'
                    : sukuVal
                    ? 'bg-sky-50 border-sky-300 text-sky-900 shadow-sm'
                    : 'bg-white border-dashed border-slate-300 hover:border-pink-300 hover:bg-pink-50/40 text-slate-400'
                }`}
              >
                <span className="text-xs font-bold text-slate-400 mb-1">
                  Suku {slotIdx + 1}
                </span>
                {sukuVal ? (
                  <span className="text-2xl font-bold tracking-wide">
                    {sukuVal}
                  </span>
                ) : (
                  <span className="text-xs italic">Tekan / Seret</span>
                )}
              </div>
            );
          })}
        </div>

        {/* Pilihan Kad Suku Kata */}
        <div className="pt-2">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2">
            Pilih Kad Suku Kata:
          </span>
          <div className="flex flex-wrap justify-center gap-2.5">
            {soalanSemasa.pilihanSuku.map((suku, idx) => {
              const isSelected = selectedSuku === suku;
              return (
                <div
                  key={idx}
                  draggable={!telahDisemak}
                  onDragStart={(e) => handleDragStart(e, suku)}
                  onClick={() => !telahDisemak && handlePilihSuku(suku)}
                  className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-bold text-base md:text-lg cursor-pointer select-none transition shadow-xs ${
                    isSelected
                      ? 'bg-pink-400 text-white shadow-md scale-105 ring-4 ring-pink-200'
                      : 'bg-white hover:bg-pink-50 border-2 border-slate-200 hover:border-pink-300 text-slate-700'
                  }`}
                >
                  <span>{suku}</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      sounds.playPop();
                      sounds.sebutPerkataan(suku);
                    }}
                    className="p-1 text-slate-400 hover:text-pink-500"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Tindakan Semak & Soalan Seterusnya */}
      <div className="flex justify-end gap-2 bg-white p-4 rounded-2xl border-2 border-slate-200/80 shadow-xs">
        {!telahDisemak ? (
          <button
            onClick={handleSemak}
            disabled={jawapanSlot.some((s) => s === null)}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs md:text-sm text-white bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 shadow-md disabled:opacity-40 disabled:cursor-not-allowed transition"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Semak Jawapan</span>
          </button>
        ) : (
          <button
            onClick={handleSeterusnya}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs md:text-sm text-white bg-gradient-to-r from-sky-400 to-indigo-500 hover:from-sky-500 hover:to-indigo-600 shadow-md transition"
          >
            <span>Soalan Seterusnya</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};
