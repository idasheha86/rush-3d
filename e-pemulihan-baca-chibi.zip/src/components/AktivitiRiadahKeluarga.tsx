import React, { useState } from 'react';
import { Volume2, RotateCcw, CheckCircle2, Sparkles, Trophy } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../utils/soundEffects';
import { ChibiMascot } from './ChibiMascot';
import { Murid, RekodAktiviti } from '../types';

interface AktivitiRiadahProps {
  muridAktif: Murid;
  onSimpanPencapaian: (rekod: RekodAktiviti, markahPeratus: number) => void;
}

interface ItemPerkataan {
  id: string;
  perkataan: string;
  padananBetul: number; // 0: membakar, 1: berehat, 2: bernyanyi, 3: bergembira
  keterangan: string;
}

const SENARAI_PERKATAAN: ItemPerkataan[] = [
  { id: 'p1', perkataan: 'bergembira', padananBetul: 0, keterangan: 'Kanak-kanak berasa sangat seronok dan riang' },
  { id: 'p2', perkataan: 'berehat', padananBetul: 1, keterangan: 'Datuk dan nenek duduk dengan tenang di bangku taman' },
  { id: 'p3', perkataan: 'bernyanyi', padananBetul: 2, keterangan: 'Ayah memetik gitar sambil mendendangkan lagu' },
  { id: 'p4', perkataan: 'membakar', padananBetul: 3, keterangan: 'Ibu sedang memanggang makanan di atas pemanggang' },
];

const SENARAI_PETAK = [
  { id: 0, tajuk: '1. Kanak-kanak bermain:', jawapanBetul: 'bergembira', ikon: '👧🧒' },
  { id: 1, tajuk: '2. Datuk dan nenek:', jawapanBetul: 'berehat', ikon: '👵👴' },
  { id: 2, tajuk: '3. Ayah memetik gitar:', jawapanBetul: 'bernyanyi', ikon: '🎸👨' },
  { id: 3, tajuk: '4. Ibu di pemanggang:', jawapanBetul: 'membakar', ikon: '🍢👩' },
];

export const AktivitiRiadahKeluarga: React.FC<AktivitiRiadahProps> = ({
  muridAktif,
  onSimpanPencapaian,
}) => {
  const [jawapanPetak, setJawapanPetak] = useState<(string | null)[]>([null, null, null, null]);
  const [selectedWord, setSelectedWord] = useState<string | null>(null);
  const [draggedWord, setDraggedWord] = useState<string | null>(null);
  const [telahSelesai, setTelahSelesai] = useState(false);
  const [skor, setSkor] = useState<number | null>(null);
  const [pesananMascot, setPesananMascot] = useState('Pilih atau seret perkataan yang sesuai ke garisan aktiviti ya?');
  const [mascotMood, setMascotMood] = useState<'happy' | 'cheer' | 'thinking' | 'wink'>('happy');

  // Perkataan yang belum diletakkan di mana-mana petak
  const perkataanTersedia = SENARAI_PERKATAAN.map(p => p.perkataan).filter(
    p => !jawapanPetak.includes(p)
  );

  const handlePilihPerkataan = (perkataan: string) => {
    sounds.playPop();
    sounds.sebutPerkataan(perkataan);
    setSelectedWord(perkataan === selectedWord ? null : perkataan);
    setPesananMascot(`Bagus! Sekarang tekan pada garisan bernombor di bawah gambar untuk letakkan perkataan "${perkataan}".`);
  };

  const handleTekanPetak = (index: number) => {
    if (telahSelesai) return;

    if (selectedWord) {
      // Letakkan perkataan terpilih ke petak ini
      sounds.playPop();
      const updated = [...jawapanPetak];
      updated[index] = selectedWord;
      setJawapanPetak(updated);
      setSelectedWord(null);
      setPesananMascot('Hebat! Teruskan untuk lengkapkan semua 4 perkataan.');
    } else if (jawapanPetak[index]) {
      // Keluarkan perkataan dari petak
      sounds.playPop();
      const updated = [...jawapanPetak];
      updated[index] = null;
      setJawapanPetak(updated);
    }
  };

  // Drag and drop handlers
  const handleDragStart = (e: React.DragEvent, perkataan: string) => {
    setDraggedWord(perkataan);
    e.dataTransfer.setData('text/plain', perkataan);
    sounds.playPop();
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (telahSelesai) return;

    const word = draggedWord || e.dataTransfer.getData('text/plain');
    if (word) {
      sounds.playCorrect();
      const updated = [...jawapanPetak];
      // Jika perkataan ini sudah ada di petak lain, keluarkan dulu
      const oldIndex = updated.indexOf(word);
      if (oldIndex !== -1) updated[oldIndex] = null;
      updated[index] = word;
      setJawapanPetak(updated);
      setDraggedWord(null);
      setSelectedWord(null);
      setPesananMascot(`Cantik! Perkataan "${word}" telah diletakkan di petak ${index + 1}.`);
    }
  };

  const handleSemakJawapan = () => {
    let betul = 0;
    jawapanPetak.forEach((jwpn, idx) => {
      if (jwpn === SENARAI_PETAK[idx].jawapanBetul) {
        betul++;
      }
    });

    const markah = Math.round((betul / SENARAI_PETAK.length) * 100);
    setSkor(markah);
    setTelahSelesai(true);

    if (markah === 100) {
      sounds.playCorrect();
      sounds.playStarChime();
      setMascotMood('cheer');
      setPesananMascot('Tahniah adik pintar! Semua 4 perkataan berjaya ditulis dan dipadankan dengan betul!');
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#F472B6', '#38BDF8', '#FBBF24', '#34D399', '#A78BFA'],
      });
    } else {
      sounds.playTryAgain();
      setMascotMood('thinking');
      setPesananMascot(`Bagus berusaha! Adik dapat ${betul} daripada 4 betul. Jom kita semak dan cuba lagi ya?`);
    }

    // Jana rekod pembelajaran ke arkib digital & kemas kini murid
    const rekod: RekodAktiviti = {
      id: `rk-${Date.now()}`,
      muridId: muridAktif.id,
      namaMurid: muridAktif.nama,
      konstrukId: 12,
      tajukAktiviti: 'Aktiviti 3: Tulis Perkataan Riadah Keluarga',
      tarikh: new Date().toLocaleDateString('ms-MY', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      markah: markah,
      bilanganBetul: betul,
      jumlahSoalan: 4,
      tempohMasaSaat: 45,
      status: markah >= 80 ? 'MENGUASAI' : markah >= 50 ? 'SEDANG' : 'BELUM',
      jenisInteraksi: 'Seret & Lepas',
    };

    onSimpanPencapaian(rekod, markah);
  };

  const handleSetSemula = () => {
    sounds.playPop();
    setJawapanPetak([null, null, null, null]);
    setSelectedWord(null);
    setTelahSelesai(false);
    setSkor(null);
    setMascotMood('happy');
    setPesananMascot('Pilih atau seret perkataan yang sesuai ke garisan aktiviti ya?');
  };

  return (
    <div className="space-y-4">
      {/* Header Aktiviti Berdasarkan Modul KPM */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-white/90 p-4 rounded-2xl border-2 border-emerald-100 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="bg-emerald-100 text-emerald-800 font-bold px-3 py-1 rounded-xl text-xs flex items-center gap-1.5 shadow-xs">
            <span>🚀 Aktiviti 3</span>
          </div>
          <div>
            <h2 className="text-base md:text-lg font-bold text-slate-800">
              Tulis perkataan.
            </h2>
            <p className="text-xs text-slate-500">
              Konstruk 12 (3.1.1(i), BT: 4) - Penguasaan Membaca & Memahami Perkataan Konseptual
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-pink-50 text-pink-700 border border-pink-200">
            Murid: {muridAktif.nama.split(' ')[0]} {muridAktif.nama.split(' ')[1] || ''}
          </span>
          <button
            onClick={handleSetSemula}
            className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
            title="Mula semula"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Mula Semula</span>
          </button>
        </div>
      </div>

      {/* Maskot Chibi Interaktif */}
      <ChibiMascot
        pesanan={pesananMascot}
        expression={mascotMood}
        namaMascot="Cikgu Kancil"
      />

      {/* Gambar Ilustrasi Digital Situasi Riadah Keluarga (Berdasarkan Imej Lembaran Kerja KPM) */}
      <div className="bg-gradient-to-b from-sky-50 via-emerald-50/60 to-amber-50/40 p-3 rounded-2xl border-2 border-sky-100 shadow-xs relative overflow-hidden">
        <div className="flex items-center justify-between px-2 mb-2">
          <span className="text-[11px] font-bold text-sky-800 uppercase tracking-wide bg-sky-100 px-2 py-0.5 rounded-full">
            Situasi: Berkelah & Beriadah di Halaman Rumah
          </span>
          <span className="text-[11px] text-slate-500">
            Perhatikan perbuatan setiap ahli keluarga
          </span>
        </div>

        {/* Pemandangan Diorama Karektor Chibi 5D Riadah Keluarga */}
        <div className="w-full bg-white rounded-2xl overflow-hidden border-2 border-slate-200 shadow-lg relative group">
          <img
            src="/src/assets/images/chibi_picnic_5d_1791950791938.jpg"
            alt="Situasi Riadah Keluarga Karektor Chibi 5D"
            referrerPolicy="no-referrer"
            className="w-full h-auto max-h-[380px] object-cover object-center transition-transform duration-500 group-hover:scale-102"
          />

          {/* Lencana Chibi 5D */}
          <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full border border-pink-200 shadow-md flex items-center gap-1.5 text-xs font-black text-pink-700">
            <span>✨ Karektor Chibi 5D Realistik</span>
          </div>

          {/* Penunjuk Interaktif 5D di Atas Gambar */}
          <div className="absolute bottom-3 inset-x-3 flex flex-wrap items-center justify-center gap-2">
            <span className="bg-pink-900/80 backdrop-blur-md text-white text-[11px] font-bold px-3 py-1 rounded-xl shadow-md border border-pink-300 flex items-center gap-1">
              🍢 Ibu Membakar
            </span>
            <span className="bg-amber-900/80 backdrop-blur-md text-white text-[11px] font-bold px-3 py-1 rounded-xl shadow-md border border-amber-300 flex items-center gap-1">
              👵👴 Datuk & Nenek Berehat
            </span>
            <span className="bg-sky-900/80 backdrop-blur-md text-white text-[11px] font-bold px-3 py-1 rounded-xl shadow-md border border-sky-300 flex items-center gap-1">
              🎸 Ayah Bernyanyi
            </span>
            <span className="bg-emerald-900/80 backdrop-blur-md text-white text-[11px] font-bold px-3 py-1 rounded-xl shadow-md border border-emerald-300 flex items-center gap-1">
              👦 Kanak-kanak Bergembira
            </span>
          </div>
        </div>
      </div>

      {/* Kad Pilihan Perkataan (Click atau Drag) */}
      <div className="bg-white p-4 rounded-2xl border-2 border-slate-200/80 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Pilihan Perkataan:
            </span>
            <span className="text-xs text-slate-400">
              (Tekan untuk pilih ATAU seret ke garisan bertulis)
            </span>
          </div>
          {selectedWord && (
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-pink-100 text-pink-700 animate-pulse">
              Dipilih: "{selectedWord}"
            </span>
          )}
        </div>

        <div className="flex flex-wrap gap-2.5">
          {SENARAI_PERKATAAN.map((item) => {
            const isUsed = jawapanPetak.includes(item.perkataan);
            const isSelected = selectedWord === item.perkataan;

            return (
              <div
                key={item.id}
                draggable={!isUsed && !telahSelesai}
                onDragStart={(e) => handleDragStart(e, item.perkataan)}
                onClick={() => !isUsed && !telahSelesai && handlePilihPerkataan(item.perkataan)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-sm md:text-base cursor-pointer select-none transition-all duration-200 shadow-sm ${
                  isUsed
                    ? 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed opacity-50'
                    : isSelected
                    ? 'bg-gradient-to-r from-pink-400 to-rose-400 text-white shadow-md scale-105 ring-4 ring-pink-200'
                    : 'bg-white hover:bg-pink-50/70 text-slate-800 border-2 border-pink-200 hover:border-pink-400 hover:scale-102 active:scale-95'
                }`}
              >
                <span>{item.perkataan}</span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    sounds.playPop();
                    sounds.sebutPerkataan(item.perkataan);
                  }}
                  className="p-1 rounded-full text-pink-500 hover:bg-pink-100 transition"
                  title="Dengar sebutan"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Petak Garisan Bertulis (Meniru Lembaran Kerja KPM Garis Bertulis) */}
      <div className="bg-white p-4 rounded-2xl border-2 border-slate-200/80 shadow-xs space-y-3">
        <div className="flex items-center justify-between border-b pb-2">
          <span className="text-xs font-bold text-slate-700 uppercase tracking-wide">
            Garisan Penulisan & Padanan Situasi:
          </span>
          <span className="text-xs text-slate-400">
            Tekan petak untuk masukkan/keluarkan perkataan
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {SENARAI_PETAK.map((petak) => {
            const perkataanSemasa = jawapanPetak[petak.id];
            const isCorrect = telahSelesai && perkataanSemasa === petak.jawapanBetul;
            const isWrong = telahSelesai && perkataanSemasa !== petak.jawapanBetul;

            return (
              <div
                key={petak.id}
                onDragOver={handleDragOver}
                onDrop={(e) => handleDrop(e, petak.id)}
                onClick={() => handleTekanPetak(petak.id)}
                className={`p-3 rounded-xl border-2 transition-all cursor-pointer relative ${
                  isCorrect
                    ? 'bg-emerald-50 border-emerald-400 ring-2 ring-emerald-200'
                    : isWrong
                    ? 'bg-rose-50 border-rose-300 ring-2 ring-rose-200'
                    : perkataanSemasa
                    ? 'bg-sky-50/60 border-sky-300 shadow-xs'
                    : 'bg-slate-50/80 border-dashed border-slate-300 hover:border-pink-300 hover:bg-pink-50/40'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700">
                    <span>{petak.ikon}</span>
                    <span>{petak.tajuk}</span>
                  </div>
                  {telahSelesai && (
                    <span>
                      {isCorrect ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <span className="text-[11px] font-bold text-rose-500">
                          (Jawapan: {petak.jawapanBetul})
                        </span>
                      )}
                    </span>
                  )}
                </div>

                {/* Garisan Tiga Khas Penulisan Sekolah Rendah KPM */}
                <div className="bg-white rounded-lg p-2.5 border border-slate-200 relative overflow-hidden flex items-center justify-center min-h-[56px]">
                  {/* Panduan Garisan 3 Baris Buku Latihan */}
                  <div className="absolute inset-x-3 top-3 border-t border-blue-200 opacity-60"></div>
                  <div className="absolute inset-x-3 top-1/2 border-t border-dashed border-rose-300 opacity-70"></div>
                  <div className="absolute inset-x-3 bottom-3 border-b border-blue-200 opacity-60"></div>

                  {perkataanSemasa ? (
                    <div className="relative z-10 flex items-center gap-2">
                      <span className="text-lg md:text-xl font-bold tracking-wider text-indigo-900">
                        {perkataanSemasa}
                      </span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          sounds.playPop();
                          sounds.sebutPerkataan(perkataanSemasa);
                        }}
                        className="p-1 rounded-full text-indigo-500 hover:bg-indigo-100"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <span className="relative z-10 text-xs font-medium text-slate-400 italic">
                      + Letak perkataan di sini
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Tindakan Semakan & Keputusan */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-2xl border-2 border-slate-200/80 shadow-xs">
        <div>
          {skor !== null ? (
            <div className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-amber-500" />
              <div>
                <span className="text-sm font-bold text-slate-800">
                  Keputusan Penilaian: {skor}%
                </span>
                <span className="ml-2 text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  {skor >= 80 ? 'Telah Menguasai' : skor >= 50 ? 'Sedang Menguasai' : 'Perlu Bimbingan'}
                </span>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-500">
              Pastikan kesemua 4 petak telah diisi sebelum menekan butang semak.
            </p>
          )}
        </div>

        <div className="flex items-center gap-2">
          {!telahSelesai ? (
            <button
              onClick={handleSemakJawapan}
              disabled={jawapanPetak.some((j) => j === null)}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs md:text-sm text-white bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 shadow-md hover:shadow-lg disabled:opacity-40 disabled:cursor-not-allowed transition transform active:scale-95"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Semak Jawapan Saya</span>
            </button>
          ) : (
            <button
              onClick={handleSetSemula}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs md:text-sm text-slate-700 bg-slate-100 hover:bg-slate-200 transition"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Cuba Latihan Semula</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
