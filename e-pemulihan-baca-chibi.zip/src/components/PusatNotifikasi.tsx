import React, { useState } from 'react';
import {
  Bell,
  CheckCircle2,
  AlertTriangle,
  Calendar,
  Send,
  Plus,
  Trash2,
  Sparkles,
  UserCheck,
} from 'lucide-react';
import { NotifikasiPeringatan, Murid } from '../types';
import { sounds } from '../utils/soundEffects';

interface PusatNotifikasiProps {
  senaraiNotifikasi: NotifikasiPeringatan[];
  senaraiMurid: Murid[];
  onTandaDibaca: (id: string) => void;
  onTandaSemuaDibaca: () => void;
  onPadamNotifikasi: (id: string) => void;
  onTambahPeringatan: (notif: NotifikasiPeringatan) => void;
}

export const PusatNotifikasi: React.FC<PusatNotifikasiProps> = ({
  senaraiNotifikasi,
  senaraiMurid,
  onTandaDibaca,
  onTandaSemuaDibaca,
  onPadamNotifikasi,
  onTambahPeringatan,
}) => {
  const [tunjukBorang, setTunjukBorang] = useState(false);
  const [tajukPeringatan, setTajukPeringatan] = useState('');
  const [mesejPeringatan, setMesejPeringatan] = useState('');
  const [muridTerpilih, setMuridTerpilih] = useState(senaraiMurid[0]?.id || '');

  const belumBacaCount = senaraiNotifikasi.filter((n) => !n.telahDibaca).length;

  const handleHantarPeringatan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tajukPeringatan.trim()) return;

    sounds.playCorrect();
    const murid = senaraiMurid.find((m) => m.id === muridTerpilih);

    const notifBaru: NotifikasiPeringatan = {
      id: `notif-${Date.now()}`,
      jenis: 'jadual_berkala',
      tajuk: tajukPeringatan.trim(),
      mesej: mesejPeringatan.trim() || 'Peringatan jadual bimbingan pemulihan khas berkala.',
      tarikh: new Date().toLocaleDateString('ms-MY', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      }),
      telahDibaca: false,
      muridId: murid?.id,
      namaMurid: murid?.nama,
    };

    onTambahPeringatan(notifBaru);
    setTunjukBorang(false);
    setTajukPeringatan('');
    setMesejPeringatan('');
  };

  return (
    <div className="space-y-6">
      {/* Header Notifikasi */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-slate-800 flex items-center gap-2">
            <Bell className="w-6 h-6 text-pink-500" />
            <span>Pusat Notifikasi & Peringatan Berkala</span>
            {belumBacaCount > 0 && (
              <span className="text-xs bg-pink-100 text-pink-800 font-bold px-2.5 py-0.5 rounded-full border border-pink-200 animate-pulse">
                {belumBacaCount} Baharu
              </span>
            )}
          </h2>
          <p className="text-xs md:text-sm text-slate-500 mt-0.5">
            Sistem amaran pintar automatik untuk memantau prestasi dan jadual bimbingan murid secara berterusan.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {belumBacaCount > 0 && (
            <button
              onClick={() => {
                sounds.playPop();
                onTandaSemuaDibaca();
              }}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition"
            >
              Tandakan Semua Dibaca
            </button>
          )}

          <button
            onClick={() => {
              sounds.playPop();
              setTunjukBorang(!tunjukBorang);
            }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-pink-400 to-rose-400 hover:from-pink-500 shadow-sm transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Cipta Peringatan Berkala</span>
          </button>
        </div>
      </div>

      {/* Borang Tambah Peringatan Berkala */}
      {tunjukBorang && (
        <form
          onSubmit={handleHantarPeringatan}
          className="bg-white p-5 rounded-2xl border-2 border-pink-300 shadow-sm space-y-3 text-xs"
        >
          <div className="flex items-center justify-between border-b pb-2">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-pink-500" />
              <span>Tetapkan Peringatan / Jadual Bimbingan Berkala</span>
            </h3>
            <button
              type="button"
              onClick={() => setTunjukBorang(false)}
              className="text-slate-400 hover:text-slate-600"
            >
              Batal
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Tajuk Peringatan:
              </label>
              <input
                type="text"
                required
                value={tajukPeringatan}
                onChange={(e) => setTajukPeringatan(e.target.value)}
                placeholder="Contoh: Saringan Ulangan Konstruk 4"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-pink-300"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Pilih Murid (Pilihan):
              </label>
              <select
                value={muridTerpilih}
                onChange={(e) => setMuridTerpilih(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-pink-300"
              >
                {senaraiMurid.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.nama} ({m.kelas})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">
              Mesej / Tindakan Bimbingan:
            </label>
            <textarea
              rows={2}
              value={mesejPeringatan}
              onChange={(e) => setMesejPeringatan(e.target.value)}
              placeholder="Contoh: Jalankan latih tubi kad imbasan suku kata tertutup sebelum penilaian akhir minggu..."
              className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-pink-300"
            />
          </div>

          <div className="flex justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => setTunjukBorang(false)}
              className="px-4 py-2 rounded-xl text-slate-600 bg-slate-100"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl font-bold text-white bg-pink-500 hover:bg-pink-600"
            >
              Simpan Peringatan
            </button>
          </div>
        </form>
      )}

      {/* Senarai Notifikasi */}
      <div className="space-y-3">
        {senaraiNotifikasi.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl border-2 border-slate-200 text-center text-slate-400 text-xs">
            Tiada notifikasi pada masa ini.
          </div>
        ) : (
          senaraiNotifikasi.map((item) => {
            const isUnread = !item.telahDibaca;

            const iconPeringatan =
              item.jenis === 'amaran_bimbingan' ? (
                <div className="w-10 h-10 rounded-xl bg-rose-100 border border-rose-200 flex items-center justify-center text-rose-600 shrink-0">
                  <AlertTriangle className="w-5 h-5" />
                </div>
              ) : item.jenis === 'kejayaan_lulus' ? (
                <div className="w-10 h-10 rounded-xl bg-emerald-100 border border-emerald-200 flex items-center justify-center text-emerald-600 shrink-0">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
              ) : item.jenis === 'peringatan_ibu_bapa' ? (
                <div className="w-10 h-10 rounded-xl bg-purple-100 border border-purple-200 flex items-center justify-center text-purple-600 shrink-0">
                  <Send className="w-5 h-5" />
                </div>
              ) : (
                <div className="w-10 h-10 rounded-xl bg-sky-100 border border-sky-200 flex items-center justify-center text-sky-600 shrink-0">
                  <Calendar className="w-5 h-5" />
                </div>
              );

            return (
              <div
                key={item.id}
                onClick={() => isUnread && onTandaDibaca(item.id)}
                className={`p-4 rounded-2xl border-2 transition-all flex items-start justify-between gap-3 ${
                  isUnread
                    ? 'bg-gradient-to-r from-pink-50/70 via-white to-sky-50/40 border-pink-200 shadow-xs ring-2 ring-pink-100 cursor-pointer'
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start gap-3 min-w-0">
                  {iconPeringatan}

                  <div className="space-y-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="text-sm font-bold text-slate-800">
                        {item.tajuk}
                      </h4>
                      {isUnread && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-pink-500 text-white">
                          Baharu
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed">
                      {item.mesej}
                    </p>

                    <div className="flex items-center gap-2 text-[11px] text-slate-400">
                      <span>{item.tarikh}</span>
                      {item.namaMurid && (
                        <>
                          <span>•</span>
                          <span className="font-semibold text-slate-600">
                            Murid: {item.namaMurid}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      sounds.playPop();
                      onPadamNotifikasi(item.id);
                    }}
                    className="p-1.5 rounded-lg text-slate-300 hover:text-rose-500 hover:bg-rose-50 transition"
                    title="Padam notifikasi"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
