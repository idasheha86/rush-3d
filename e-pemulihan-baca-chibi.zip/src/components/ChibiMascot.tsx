import React from 'react';
import { Volume2 } from 'lucide-react';
import { sounds } from '../utils/soundEffects';

interface ChibiMascotProps {
  expression?: 'happy' | 'cheer' | 'thinking' | 'wink';
  pesanan?: string;
  namaMascot?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const ChibiMascot: React.FC<ChibiMascotProps> = ({
  expression = 'happy',
  pesanan = 'Selamat belajar adik! Tarik dan susun suku kata dengan betul ya?',
  namaMascot = 'Si Kancil Pintar',
  size = 'md',
}) => {
  const handleSebut = () => {
    sounds.playPop();
    sounds.sebutPerkataan(pesanan);
  };

  const sizeClasses = {
    sm: 'w-16 h-16',
    md: 'w-24 h-24 md:w-28 md:h-28',
    lg: 'w-32 h-32 md:w-36 md:h-36',
  };

  return (
    <div className="flex items-center gap-3 bg-gradient-to-r from-amber-50/90 via-pink-50/90 to-sky-50/90 p-3 rounded-2xl border-2 border-pink-200/60 shadow-sm relative overflow-hidden">
      {/* Decorative Pastel Background Sparkles */}
      <div className="absolute top-1 right-2 text-pink-300 text-xs select-none">✨</div>
      <div className="absolute bottom-1 left-3 text-sky-300 text-xs select-none">⭐</div>

      {/* Chibi Character SVG */}
      <div className={`${sizeClasses[size]} shrink-0 relative transition-transform duration-300 hover:scale-105`}>
        <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-md">
          <defs>
            <radialGradient id="chibiBlush" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stop-color="#FB7185" stop-opacity="0.7" />
              <stop offset="100%" stop-color="#FB7185" stop-opacity="0" />
            </radialGradient>
            <linearGradient id="furGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#FED7AA" />
              <stop offset="100%" stop-color="#FDBA74" />
            </linearGradient>
            <linearGradient id="earInner" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#FCE7F3" />
              <stop offset="100%" stop-color="#F472B6" />
            </linearGradient>
          </defs>

          {/* Cute Little Body */}
          <ellipse cx="60" cy="98" rx="28" ry="18" fill="#FDBA74" />
          <ellipse cx="60" cy="98" rx="16" ry="12" fill="#FFFBEB" />
          {/* Hands */}
          <ellipse cx="38" cy="94" rx="8" ry="6" fill="#FB923C" />
          <ellipse cx="82" cy="94" rx="8" ry="6" fill="#FB923C" />

          {/* Big Chibi Ears */}
          <polygon points="35,45 20,10 50,30" fill="url(#furGradient)" rx="4" />
          <polygon points="36,40 25,18 46,30" fill="url(#earInner)" opacity="0.85" />
          <polygon points="85,45 100,10 70,30" fill="url(#furGradient)" rx="4" />
          <polygon points="84,40 95,18 74,30" fill="url(#earInner)" opacity="0.85" />

          {/* Cute Chibi Head */}
          <circle cx="60" cy="56" r="38" fill="url(#furGradient)" stroke="#EA580C" stroke-width="1.5" />
          <path d="M 38 70 C 45 80, 75 80, 82 70 C 75 62, 45 62, 38 70 Z" fill="#FFFBEB" />

          {/* Cute Big Chibi Eyes */}
          {expression === 'wink' ? (
            <>
              {/* Left wink */}
              <path d="M42 54 Q49 61 56 54" stroke="#1E293B" stroke-width="3.5" stroke-linecap="round" fill="none" />
              {/* Right big eye */}
              <ellipse cx="74" cy="52" rx="7" ry="10" fill="#1E293B" />
              <circle cx="72" cy="49" r="3" fill="#FFFFFF" />
              <circle cx="76" cy="55" r="1.5" fill="#FFFFFF" />
            </>
          ) : expression === 'cheer' ? (
            <>
              {/* Cheerful curved closed eyes (^^) */}
              <path d="M40 54 Q48 44 56 54" stroke="#1E293B" stroke-width="3.5" stroke-linecap="round" fill="none" />
              <path d="M64 54 Q72 44 80 54" stroke="#1E293B" stroke-width="3.5" stroke-linecap="round" fill="none" />
            </>
          ) : (
            <>
              {/* Big sparkling anime chibi eyes */}
              <ellipse cx="46" cy="52" rx="7.5" ry="10" fill="#1E293B" />
              <circle cx="44" cy="48" r="3" fill="#FFFFFF" />
              <circle cx="48" cy="55" r="1.5" fill="#FFFFFF" />

              <ellipse cx="74" cy="52" rx="7.5" ry="10" fill="#1E293B" />
              <circle cx="72" cy="48" r="3" fill="#FFFFFF" />
              <circle cx="76" cy="55" r="1.5" fill="#FFFFFF" />
            </>
          )}

          {/* Rosy Cheeks */}
          <ellipse cx="36" cy="62" rx="7" ry="4" fill="url(#chibiBlush)" />
          <ellipse cx="84" cy="62" rx="7" ry="4" fill="url(#chibiBlush)" />

          {/* Cute Little Nose */}
          <ellipse cx="60" cy="59" rx="3" ry="2" fill="#7C2D12" />

          {/* Smiling Mouth */}
          {expression === 'cheer' ? (
            <path d="M54 64 Q60 74 66 64 Z" fill="#E11D48" />
          ) : (
            <path d="M55 63 Q60 69 65 63" stroke="#7C2D12" stroke-width="2.5" stroke-linecap="round" fill="none" />
          )}

          {/* Cute Little Academic Bowtie / Songkok Kecil */}
          <path d="M53 82 L60 85 L67 82 L64 88 L60 86 L56 88 Z" fill="#0284C7" />
          <circle cx="60" cy="85" r="2.5" fill="#FBBF24" />
        </svg>
      </div>

      {/* Dialogue Speech Bubble */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 mb-1">
          <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider bg-amber-100/80 px-2 py-0.5 rounded-full">
            {namaMascot}
          </span>
          <button
            onClick={handleSebut}
            title="Dengar suara bimbingan"
            className="p-1 rounded-full text-pink-500 hover:bg-pink-100 transition active:scale-90"
          >
            <Volume2 className="w-3.5 h-3.5" />
          </button>
        </div>
        <p className="text-xs md:text-sm font-semibold text-slate-700 leading-snug">
          "{pesanan}"
        </p>
      </div>
    </div>
  );
};
