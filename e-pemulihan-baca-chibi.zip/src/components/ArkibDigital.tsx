import React, { useState } from 'react';
import {
  Archive,
  Search,
  Filter,
  Download,
  Calendar,
  CheckCircle2,
  Clock,
  Printer,
  FileSpreadsheet,
} from 'lucide-react';
import { RekodAktiviti } from '../types';
import { SENARAI_KONSTRUK_KPM } from '../data/kpmKonstruk';
import { sounds } from '../utils/soundEffects';

interface ArkibDigitalProps {
  senaraiRekod: RekodAktiviti[];
}

export const ArkibDigital: React.FC<ArkibDigitalProps> = ({ senaraiRekod }) => {
  const [carian, setCarian] = useState('');
  const [tapisKonstruk, setTapisKonstruk] = useState<string>('Semua');
  const [tapisStatus, setTapisStatus] = useState<string>('Semua');

  const rekodDitapis = senaraiRekod.filter((rekod) => {
    const padanCari =
      rekod.namaMurid.toLowerCase().includes(carian.toLowerCase()) ||
      rekod.tajukAktiviti.toLowerCase().includes(carian.toLowerCase());
    const padanKonstruk =
      tapisKonstruk === 'Semua' || rekod.konstrukId.toString() === tapisKonstruk;
    const padanStatus =
      tapisStatus === 'Semua' || rekod.status === tapisStatus;

    return padanCari && padanKonstruk && padanStatus;
  });

  const handleEksportCSV = () => {
    sounds.playPop();
    const headers = ['ID Rekod', 'Nama Murid', 'Konstruk ID', 'Tajuk Aktiviti', 'Tarikh', 'Markah (%)', 'Bil. Betul', 'Jumlah Soalan', 'Masa (Saat)', 'Status', 'Jenis Interaksi'];
    const rows = rekodDitapis.map((r) => [
      r.id,
      `"${r.namaMurid}"`,
      r.konstrukId,
      `"${r.tajukAktiviti}"`,
      `"${r.tarikh}"`,
      r.markah,
      r.bilanganBetul,
      r.jumlahSoalan,
      r.tempohMasaSaat,
      r.status,
      `"${r.jenisInteraksi}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Arkib_Pemulihan_Khas_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header Arkib */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-slate-800 flex items-center gap-2">
            <Archive className="w-6 h-6 text-indigo-500" />
            <span>Arkib Digital Sejarah Pembelajaran Murid</span>
          </h2>
          <p className="text-xs md:text-sm text-slate-500 mt-0.5">
            Penyimpanan data sejarah penilaian, aktiviti harian dan kemajuan murid secara tersusun.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleEksportCSV}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-emerald-800 bg-emerald-100 hover:bg-emerald-200 border border-emerald-300 transition active:scale-95"
            title="Eksport data arkib ke fail CSV"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
            <span>Eksport Data CSV</span>
          </button>
        </div>
      </div>

      {/* Bar Carian & Penapis */}
      <div className="bg-white p-4 rounded-2xl border-2 border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex-1 min-w-[200px] relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari dalam arkib: nama murid, aktiviti..."
            value={carian}
            onChange={(e) => setCarian(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-300"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <select
            value={tapisKonstruk}
            onChange={(e) => setTapisKonstruk(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-300 font-semibold text-slate-700"
          >
            <option value="Semua">Semua Konstruk (1 - 12)</option>
            {SENARAI_KONSTRUK_KPM.map((k) => (
              <option key={k.id} value={k.id.toString()}>
                {k.kod} - {k.tajuk.substring(0, 24)}...
              </option>
            ))}
          </select>

          <select
            value={tapisStatus}
            onChange={(e) => setTapisStatus(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-300 font-semibold text-slate-700"
          >
            <option value="Semua">Semua Status</option>
            <option value="MENGUASAI">Telah Menguasai</option>
            <option value="SEDANG">Sedang Menguasai</option>
            <option value="BELUM">Belum Menguasai</option>
          </select>
        </div>
      </div>

      {/* Senarai Rekod Arkib */}
      <div className="bg-white rounded-2xl border-2 border-slate-200 overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
            Senarai Rekod Pembelajaran ({rekodDitapis.length} rekod disimpan)
          </span>
          <span className="text-xs text-slate-400">
            Disimpan secara masa nyata dalam arkib digital
          </span>
        </div>

        {rekodDitapis.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-xs">
            Tiada rekod ditemui bagi tapisan yang dipilih.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {rekodDitapis.map((rekod) => {
              const konstrukInfo = SENARAI_KONSTRUK_KPM.find(
                (k) => k.id === rekod.konstrukId
              );

              return (
                <div
                  key={rekod.id}
                  className="p-4 hover:bg-slate-50/70 transition flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-bold text-slate-900 text-sm">
                        {rekod.namaMurid}
                      </span>
                      <span className="font-bold px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-200 text-[11px]">
                        Konstruk {rekod.konstrukId}
                      </span>
                      <span
                        className={`font-bold px-2.5 py-0.5 rounded-full text-[10px] ${
                          rekod.status === 'MENGUASAI'
                            ? 'bg-emerald-100 text-emerald-800'
                            : rekod.status === 'SEDANG'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {rekod.status === 'MENGUASAI'
                          ? 'Menguasai'
                          : rekod.status === 'SEDANG'
                          ? 'Sedang Bimbingan'
                          : 'Belum Menguasai'}
                      </span>
                    </div>

                    <div className="text-slate-600 font-medium">
                      {rekod.tajukAktiviti}
                    </div>

                    <div className="flex items-center gap-3 text-slate-400 text-[11px]">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        <span>{rekod.tarikh}</span>
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>{rekod.tempohMasaSaat} saat</span>
                      </span>
                      <span>•</span>
                      <span>Interaksi: {rekod.jenisInteraksi}</span>
                    </div>
                  </div>

                  <div className="text-left md:text-right shrink-0">
                    <div className="text-lg font-extrabold text-indigo-700">
                      {rekod.markah}%
                    </div>
                    <div className="text-[11px] text-slate-500 font-semibold">
                      {rekod.bilanganBetul} / {rekod.jumlahSoalan} soalan betul
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
