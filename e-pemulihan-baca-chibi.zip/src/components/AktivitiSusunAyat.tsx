import React, { useState } from 'react';
import { Volume2, CheckCircle2, RotateCcw, ChevronRight, Trophy } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../utils/soundEffects';
import { ChibiMascot } from './ChibiMascot';
import { Murid, RekodAktiviti } from '../types';

interface AktivitiSusunAyatProps {
  muridAktif: Murid;
  onSimpanPencapaian: (rekod: RekodAktiviti, markahPeratus: number) => void;
}

interface SoalanAyat {
  id: string;
  ayatPenuh: string;
  perkataanTersusun: string[];
  perkataanRawak: string[];
  pembayang: string;
  ikon: string;
}

const SENARAI_AYAT: SoalanAyat[] = [
  {
    id: 'ayt-1',
    ayatPenuh: 'Ibu membakar sate ayam.',
    perkataanTersusun: ['Ibu', 'membakar', 'sate', 'ayam.'],
    perkataanRawak: ['ayam.', 'membakar', 'Ibu', 'sate'],
    pembayang: 'Ibu sedang memasak makanan di atas pemanggang.',
    ikon: '🍢',
  },
  {
    id: 'ayt-2',
    ayatPenuh: 'Ayah bernyanyi memetik gitar.',
    perkataanTersusun: ['Ayah', 'bernyanyi', 'memetik', 'gitar.'],
    perkataanRawak: ['gitar.', 'Ayah', 'memetik', 'bernyanyi'],
    pembayang: 'Ayah mendendangkan lagu riang bersama keluarga.',
    ikon: '🎸',
  },
  {
    id: 'ayt-3',
    ayatPenuh: 'Datuk dan nenek berehat.',
    perkataanTersusun: ['Datuk', 'dan', 'nenek', 'berehat.'],
    perkataanRawak: ['berehat.', 'nenek', 'Datuk', 'dan'],
    pembayang: 'Warga emas duduk dengan selesa di bangku.',
    ikon: '👵👴',
  },
  {
    id: 'ayt-4',
    ayatPenuh: 'Kanak-kanak bergembira di taman.',
    perkataanTersusun: ['Kanak-kanak', 'bergembira', 'di', 'taman.'],
    perkataanRawak: ['taman.', 'Kanak-kanak', 'di', 'bergembira'],
    pembayang: 'Semua anak berasa amat seronok beriadah.',
    ikon: '🎈',
  },
];

export const AktivitiSusunAyat: React.FC<AktivitiSusunAyatProps> = ({
  muridAktif,
  onSimpanPencapaian,
}) => {
  const [indexAyat, setIndexAyat] = useState(0);
  const [susunanMurid, setSusunanMurid] = useState<string[]>([]);
  const [telahDisemak, setTelahDisemak] = useState(false);
  const [adakahBetul, setAdakahBetul] = useState<boolean | null>(null);
  const [jumlahBetul, setJumlahBetul] = useState(0);
  const [selesaiSemua, setSelesaiSemua] = useState(false);
  const [pesananMascot, setPesananMascot] = useState('Susun perkataan mengikut urutan yang betul untuk membentuk ayat yang bermakna.');

  const soalan = SENARAI_AYAT[indexAyat];

  const perkataanBaki = soalan.perkataanRawak.filter(
    (w) => !susunanMurid.includes(w)
  );

  const handleTekanPerkataan = (kata: string) => {
    if (telahDisemak) return;
    sounds.playPop();
    sounds.sebutPerkataan(kata.replace('.', ''));
    setSusunanMurid([...susunanMurid, kata]);
  };

  const handleKeluarkanPerkataan = (index: number) => {
    if (telahDisemak) return;
    sounds.playPop();
    const updated = [...susunanMurid];
    updated.splice(index, 1);
    setSusunanMurid(updated);
  };

  const handleSemak = () => {
    const ayatDibina = susunanMurid.join(' ');
    const betul = ayatDibina === soalan.ayatPenuh;

    setTelahDisemak(true);
    setAdakahBetul(betul);

    if (betul) {
      sounds.playCorrect();
      sounds.playStarChime();
      sounds.sebutPerkataan(soalan.ayatPenuh);
      setJumlahBetul((prev) => prev + 1);
      setPesananMascot(`Bijaknya! Ayat yang dibina amat tepat: "${soalan.ayatPenuh}"!`);
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#F472B6', '#38BDF8', '#34D399', '#FBBF24'],
      });
    } else {
      sounds.playTryAgain();
      setPesananMascot(`Cuba lagi. Ayat yang betul ialah: "${soalan.ayatPenuh}".`);
    }
  };

  const handleSeterusnya = () => {
    sounds.playPop();
    if (indexAyat < SENARAI_AYAT.length - 1) {
      setIndexAyat((prev) => prev + 1);
      setSusunanMurid([]);
      setTelahDisemak(false);
      setAdakahBetul(null);
      setPesananMascot('Mari susun ayat mudah yang seterusnya ya?');
    } else {
      const markahAkhir = Math.round(
        ((jumlahBetul + (adakahBetul ? 1 : 0)) / SENARAI_AYAT.length) * 100
      );
      setSelesaiSemua(true);

      const rekod: RekodAktiviti = {
        id: `rk-${Date.now()}`,
        muridId: muridAktif.id,
        namaMurid: muridAktif.nama,
        konstrukId: 12,
        tajukAktiviti: 'Aktiviti Susun Ayat Mudah Bermakna',
        tarikh: new Date().toLocaleDateString('ms-MY', {
          day: 'numeric',
          month: 'long',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        }),
        markah: markahAkhir,
        bilanganBetul: jumlahBetul + (adakahBetul ? 1 : 0),
        jumlahSoalan: SENARAI_AYAT.length,
        tempohMasaSaat: 55,
        status: markahAkhir >= 80 ? 'MENGUASAI' : markahAkhir >= 50 ? 'SEDANG' : 'BELUM',
        jenisInteraksi: 'Klik & Padan',
      };

      onSimpanPencapaian(rekod, markahAkhir);
    }
  };

  const handleMulaSemula = () => {
    sounds.playPop();
    setIndexAyat(0);
    setSusunanMurid([]);
    setTelahDisemak(false);
    setAdakahBetul(null);
    setJumlahBetul(0);
    setSelesaiSemua(false);
    setPesananMascot('Susun perkataan mengikut urutan yang betul untuk membentuk ayat yang bermakna.');
  };

  if (selesaiSemua) {
    const peratus = Math.round((jumlahBetul / SENARAI_AYAT.length) * 100);
    return (
      <div className="bg-white p-6 rounded-3xl border-2 border-emerald-200 text-center space-y-4 shadow-sm">
        <div className="w-16 h-16 mx-auto rounded-full bg-emerald-100 flex items-center justify-center text-3xl">
          🏆
        </div>
        <h3 className="text-xl font-bold text-slate-800">
          Modul Susun Ayat Selesai
        </h3>
        <p className="text-sm text-slate-600">
          {muridAktif.nama} berjaya membina {jumlahBetul} daripada {SENARAI_AYAT.length} ayat dengan markah <strong>{peratus}%</strong>.
        </p>

        <button
          onClick={handleMulaSemula}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs md:text-sm text-white bg-gradient-to-r from-emerald-500 to-teal-500 shadow-md transition"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Ulang Latihan Susun Ayat</span>
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header Aktiviti Susun Ayat */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-white/90 p-4 rounded-2xl border-2 border-emerald-100 shadow-sm">
        <div>
          <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full">
            Konstruk 12 - Membaca & Menyusun Ayat Mudah
          </span>
          <h2 className="text-base md:text-lg font-bold text-slate-800 mt-1">
            Bina Ayat Berdasarkan Situasi
          </h2>
          <p className="text-xs text-slate-500">
            Ayat {indexAyat + 1} daripada {SENARAI_AYAT.length}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-pink-50 text-pink-700 border border-pink-200">
            Pencapaian: {jumlahBetul} / {SENARAI_AYAT.length}
          </span>
          <button
            onClick={handleMulaSemula}
            className="p-2 text-slate-500 hover:bg-slate-100 rounded-xl transition"
            title="Set semula"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Maskot Chibi */}
      <ChibiMascot
        pesanan={pesananMascot}
        expression={adakahBetul ? 'cheer' : 'happy'}
        namaMascot="Cikgu Aina Chibi"
      />

      {/* Kawasan Binaan Ayat */}
      <div className="bg-white p-5 rounded-3xl border-2 border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-2xl">{soalan.ikon}</span>
            <span className="text-xs text-slate-500 italic">
              Petunjuk: "{soalan.pembayang}"
            </span>
          </div>
          <button
            onClick={() => sounds.sebutPerkataan(soalan.ayatPenuh)}
            className="flex items-center gap-1 text-xs font-semibold text-sky-600 hover:text-sky-700 bg-sky-50 px-2.5 py-1 rounded-lg"
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>Dengar Ayat</span>
          </button>
        </div>

        {/* Petak Garisan Ayat Murid */}
        <div
          className={`min-h-[70px] p-4 rounded-2xl border-2 flex flex-wrap items-center gap-2 transition-all ${
            telahDisemak && adakahBetul
              ? 'bg-emerald-50 border-emerald-400'
              : telahDisemak && !adakahBetul
              ? 'bg-rose-50 border-rose-300'
              : 'bg-slate-50/80 border-dashed border-sky-300'
          }`}
        >
          {susunanMurid.length === 0 ? (
            <span className="text-xs text-slate-400 italic">
              Tekan perkataan di bawah untuk mula menyusun ayat...
            </span>
          ) : (
            susunanMurid.map((kata, idx) => (
              <span
                key={idx}
                onClick={() => handleKeluarkanPerkataan(idx)}
                className="px-3.5 py-1.5 rounded-xl font-bold text-sm md:text-base bg-indigo-50 text-indigo-900 border border-indigo-200 cursor-pointer hover:bg-rose-100 hover:border-rose-300 hover:text-rose-700 transition shadow-xs"
                title="Tekan untuk batalkan"
              >
                {kata}
              </span>
            ))
          )}
        </div>

        {/* Bank Perkataan Yang Disediakan */}
        <div>
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2">
            Pilihan Perkataan:
          </span>
          <div className="flex flex-wrap gap-2">
            {perkataanBaki.map((kata, idx) => (
              <button
                key={idx}
                onClick={() => handleTekanPerkataan(kata)}
                className="px-4 py-2 rounded-xl font-bold text-sm md:text-base bg-white hover:bg-sky-50 text-slate-700 border-2 border-slate-200 hover:border-sky-300 shadow-xs transition transform active:scale-95"
              >
                {kata}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Tindakan Semakan */}
      <div className="flex justify-end gap-2 bg-white p-4 rounded-2xl border-2 border-slate-200 shadow-xs">
        {!telahDisemak ? (
          <button
            onClick={handleSemak}
            disabled={susunanMurid.length === 0}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs md:text-sm text-white bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 shadow-md disabled:opacity-40 disabled:cursor-not-allowed transition"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Semak Ayat</span>
          </button>
        ) : (
          <button
            onClick={handleSeterusnya}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs md:text-sm text-white bg-gradient-to-r from-sky-400 to-indigo-500 hover:from-sky-500 shadow-md transition"
          >
            <span>Ayat Seterusnya</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};
