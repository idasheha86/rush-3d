import React, { useState } from 'react';
import {
  Printer,
  ChevronLeft,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  Star,
  Award,
  Save,
  MessageSquare,
  Share2,
} from 'lucide-react';
import { Murid, RekodAktiviti } from '../types';
import { SENARAI_KONSTRUK_KPM } from '../data/kpmKonstruk';
import { sounds } from '../utils/soundEffects';

interface LaporanProps {
  murid: Murid;
  senaraiRekod: RekodAktiviti[];
  onKemaskiniCatatan: (muridId: string, catatanBaru: string) => void;
  onKembali: () => void;
}

export const LaporanKemajuanIndividu: React.FC<LaporanProps> = ({
  murid,
  senaraiRekod,
  onKemaskiniCatatan,
  onKembali,
}) => {
  const [ulasanGuru, setUlasanGuru] = useState(murid.catatanGuru);
  const [tersimpan, setTersimpan] = useState(false);

  // Rekod aktiviti murid ini sahaja
  const rekodMurid = senaraiRekod.filter((r) => r.muridId === murid.id);

  // Kiraan penguasaan 12 konstruk
  const konstrukMenguasai = Object.entries(murid.tahapKonstruk).filter(
    ([_, k]) => k.status === 'MENGUASAI'
  ).length;

  const peratusPencapaian = Math.round((konstrukMenguasai / 12) * 100);

  const handleSimpanUlasan = () => {
    sounds.playCorrect();
    onKemaskiniCatatan(murid.id, ulasanGuru);
    setTersimpan(true);
    setTimeout(() => setTersimpan(false), 2500);
  };

  const handleCetak = () => {
    sounds.playPop();
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Bar Tindakan Atas (Tidak dicetak semasa print) */}
      <div className="flex flex-wrap items-center justify-between gap-3 no-print bg-white p-4 rounded-2xl border-2 border-slate-200 shadow-xs">
        <button
          onClick={onKembali}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 transition"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Kembali ke Papan Pemuka</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCetak}
            className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-sky-500 to-indigo-500 hover:from-sky-600 shadow-sm transition active:scale-95"
          >
            <Printer className="w-4 h-4" />
            <span>Cetak / Simpan PDF Laporan</span>
          </button>
        </div>
      </div>

      {/* Dokumen Laporan Rasmi Bergaya Pemulihan Khas KPM (Printable) */}
      <div className="printable-report bg-white p-6 md:p-8 rounded-3xl border-2 border-slate-200 shadow-md space-y-6 text-slate-800">
        {/* Kepala Surat Rasmi (Header KPM) */}
        <div className="border-b-2 border-slate-800 pb-4 flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-sky-100 via-pink-100 to-amber-100 border-2 border-sky-300 flex items-center justify-center text-3xl shadow-sm">
              🏫
            </div>
            <div>
              <h1 className="text-lg md:text-xl font-extrabold uppercase tracking-wide text-slate-900">
                Program Pemulihan Khas Kementerian Pendidikan Malaysia
              </h1>
              <p className="text-xs font-semibold text-slate-600">
                Laporan Kemajuan Individu Penguasaan Literasi Membaca (Masa Nyata)
              </p>
              <p className="text-[11px] text-slate-400">
                Dokumen Rujukan Guru Pemulihan Khas dan Ibu Bapa / Penjaga
              </p>
            </div>
          </div>

          <div className="text-right text-xs text-slate-600">
            <div className="font-bold text-sky-800 bg-sky-50 px-3 py-1 rounded-lg border border-sky-200 inline-block">
              Tarikh Jana: {new Date().toLocaleDateString('ms-MY', { day: 'numeric', month: 'long', year: 'numeric' })}
            </div>
          </div>
        </div>

        {/* Maklumat Murid & Penjaga */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-50/70 p-4 rounded-2xl border border-slate-200 text-xs">
          <div className="space-y-1.5">
            <div>
              <span className="text-slate-400">Nama Murid: </span>
              <strong className="text-slate-900 text-sm">{murid.nama}</strong>
            </div>
            <div>
              <span className="text-slate-400">No. Kad Pengenalan / MyKid: </span>
              <strong>{murid.noMyKid}</strong>
            </div>
            <div>
              <span className="text-slate-400">Kelas & Tahun: </span>
              <strong>{murid.kelas} ({murid.tahun})</strong>
            </div>
          </div>

          <div className="space-y-1.5">
            <div>
              <span className="text-slate-400">Nama Ibu Bapa / Penjaga: </span>
              <strong>{murid.namaPenjaga}</strong>
            </div>
            <div>
              <span className="text-slate-400">No. Telefon Penjaga: </span>
              <strong>{murid.noTelPenjaga}</strong>
            </div>
            <div>
              <span className="text-slate-400">Tahap Penguasaan Semasa: </span>
              <span className={`font-bold px-2 py-0.5 rounded-full ${
                peratusPencapaian >= 80
                  ? 'bg-emerald-100 text-emerald-800'
                  : peratusPencapaian >= 50
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-rose-100 text-rose-800'
              }`}>
                {konstrukMenguasai} daripada 12 Konstruk ({peratusPencapaian}%)
              </span>
            </div>
          </div>
        </div>

        {/* Ringkasan Gamifikasi & Motivasi Murid */}
        <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 bg-gradient-to-r from-pink-50 via-purple-50 to-sky-50 rounded-2xl border border-pink-100">
          <div className="flex items-center gap-2">
            <span className="text-xl">⭐</span>
            <span className="text-xs font-bold text-slate-700">
              Kutipan Bintang Gamifikasi: <strong className="text-amber-600">{murid.bintang} Bintang</strong>
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs font-semibold text-slate-500">Lencana Diperoleh:</span>
            {murid.lencana.map((lenc, idx) => (
              <span
                key={idx}
                className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-white text-indigo-700 border border-indigo-200 shadow-xs"
              >
                🏅 {lenc}
              </span>
            ))}
          </div>
        </div>

        {/* Analisis Terperinci 12 Konstruk Literasi Bahasa Melayu */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
            <Award className="w-4 h-4 text-sky-600" />
            <span>Matriks Penguasaan 12 Konstruk Literasi Pemulihan Khas</span>
          </h3>

          <div className="border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-100 text-slate-700 font-bold border-b">
                <tr>
                  <th className="p-3">Kod</th>
                  <th className="p-3">Kemahiran / Konstruk</th>
                  <th className="p-3">Contoh Sukatan</th>
                  <th className="p-3 text-center">Status</th>
                  <th className="p-3 text-right">Skor (%)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {SENARAI_KONSTRUK_KPM.map((kon) => {
                  const tahap = murid.tahapKonstruk[kon.id];
                  const status = tahap?.status || 'BELUM';
                  const peratus = tahap?.peratus || 0;

                  return (
                    <tr key={kon.id} className="hover:bg-slate-50/60 transition">
                      <td className="p-3 font-bold text-indigo-800">{kon.kod}</td>
                      <td className="p-3 font-semibold text-slate-800">
                        {kon.tajuk}
                        {tahap?.catatan && (
                          <span className="block text-[11px] text-slate-400 font-normal italic mt-0.5">
                            Nota: {tahap.catatan}
                          </span>
                        )}
                      </td>
                      <td className="p-3 text-slate-500">{kon.contoh}</td>
                      <td className="p-3 text-center">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                            status === 'MENGUASAI'
                              ? 'bg-emerald-100 text-emerald-800'
                              : status === 'SEDANG'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {status === 'MENGUASAI'
                            ? 'Telah Menguasai'
                            : status === 'SEDANG'
                            ? 'Sedang Bimbingan'
                            : 'Belum Menguasai'}
                        </span>
                      </td>
                      <td className="p-3 text-right font-bold text-slate-800">
                        {peratus}%
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Sejarah Rekod Penilaian Terkini Murid */}
        {rekodMurid.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wide">
              Rekod Aktiviti Interaktif Terkini (Arkib Digital Murid)
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {rekodMurid.slice(0, 4).map((rekod) => (
                <div
                  key={rekod.id}
                  className="p-3 rounded-xl border border-slate-200 bg-slate-50/50 flex items-center justify-between"
                >
                  <div>
                    <strong className="block text-slate-800">{rekod.tajukAktiviti}</strong>
                    <span className="text-[11px] text-slate-400">{rekod.tarikh}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-bold text-indigo-700">{rekod.markah}%</span>
                    <span className="block text-[10px] text-slate-500">{rekod.jenisInteraksi}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Ulasan Guru Pemulihan Khas & Cadangan Untuk Ibu Bapa */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Ulasan Guru (Boleh Disunting) */}
          <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-200 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Ulasan Guru Pemulihan Khas:</span>
              </label>
              <button
                onClick={handleSimpanUlasan}
                className="no-print flex items-center gap-1 text-[11px] font-bold text-amber-800 hover:text-amber-900 bg-amber-200/60 hover:bg-amber-200 px-2.5 py-1 rounded-lg transition"
              >
                <Save className="w-3 h-3" />
                <span>{tersimpan ? 'Disimpan!' : 'Simpan Ulasan'}</span>
              </button>
            </div>
            <textarea
              value={ulasanGuru}
              onChange={(e) => setUlasanGuru(e.target.value)}
              rows={3}
              placeholder="Masukkan ulasan kemajuan murid untuk makluman ibu bapa..."
              className="w-full text-xs p-2.5 rounded-xl border border-amber-200 bg-white focus:outline-none focus:ring-2 focus:ring-amber-300"
            />
          </div>

          {/* Cadangan Bimbingan di Rumah untuk Ibu Bapa */}
          <div className="p-4 rounded-2xl bg-sky-50/60 border border-sky-200 space-y-1.5 text-xs text-sky-950">
            <h4 className="font-bold text-sky-900 flex items-center gap-1.5">
              <span>🏠 Cadangan Bimbingan di Rumah untuk Ibu Bapa:</span>
            </h4>
            <ul className="list-disc pl-4 space-y-1 text-slate-700 leading-relaxed text-[11px]">
              <li>
                Lakukan aktiviti mengeja bersama anak selama 10-15 minit setiap malam secara santai.
              </li>
              <li>
                Gunakan kad imbasan suku kata berwarna pastel untuk menarik perhatian anak.
              </li>
              <li>
                Berikan pujian dan sokongan moral berterusan bagi setiap peningkatan kecil.
              </li>
              <li>
                Bimbing anak mengulang aktiviti seret dan lepas di aplikasi telefon pintar.
              </li>
            </ul>
          </div>
        </div>

        {/* Bahagian Pengesahan Rasmi & Tandatangan */}
        <div className="pt-8 border-t border-slate-200 grid grid-cols-2 gap-8 text-xs text-slate-700">
          <div className="text-center space-y-12">
            <p className="font-semibold">Disediakan oleh:</p>
            <div>
              <div className="w-48 border-b-2 border-slate-400 mx-auto mb-1"></div>
              <strong className="block text-slate-800">Guru Pemulihan Khas</strong>
              <span className="text-[11px] text-slate-500">Unit Pendidikan Khas & Pemulihan</span>
            </div>
          </div>

          <div className="text-center space-y-12">
            <p className="font-semibold">Disahkan & Diterima oleh:</p>
            <div>
              <div className="w-48 border-b-2 border-slate-400 mx-auto mb-1"></div>
              <strong className="block text-slate-800">Tandatangan Ibu Bapa / Penjaga</strong>
              <span className="text-[11px] text-slate-500">Tarikh: ............................................</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
