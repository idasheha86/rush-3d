import React from 'react';
import { Trophy, Star, Award, Sparkles, Smile, Heart, CheckCircle2 } from 'lucide-react';
import { Murid } from '../types';
import { sounds } from '../utils/soundEffects';
import confetti from 'canvas-confetti';

interface GamifikasiProps {
  murid: Murid;
  onTukarAvatar: (muridId: string, avatarBaru: string) => void;
}

const SENARAI_AVATAR = [
  { id: 'kancil', nama: 'Si Kancil Pintar', ikon: '🦌', warna: 'bg-amber-100 border-amber-300' },
  { id: 'kucing', nama: 'Si Kucing Belang', ikon: '🐱', warna: 'bg-pink-100 border-pink-300' },
  { id: 'arnab', nama: 'Si Arnab Cerdik', ikon: '🐰', warna: 'bg-sky-100 border-sky-300' },
  { id: 'beruang', nama: 'Si Beruang Tabah', ikon: '🐻', warna: 'bg-purple-100 border-purple-300' },
];

const SEMUA_LENCANA = [
  { id: 'Bintang Abjad', nama: 'Bintang Abjad', ikon: '🔤', desc: 'Menguasai huruf vokal & konsonan KPM' },
  { id: 'Pakar Suku Kata', nama: 'Pakar Suku Kata', ikon: '🧩', desc: 'Membunyikan suku kata terbuka & tertutup' },
  { id: 'Wira KV', nama: 'Wira Suku Kata KV', ikon: '⭐', desc: 'Mencantumkan suku kata KV + KV dengan tepat' },
  { id: 'Juara Membaca', nama: 'Juara Membaca Ayat', ikon: '📖', desc: 'Menyusun dan membaca ayat mudah bersiri' },
  { id: 'Bintang Cemerlang', nama: 'Bintang Cemerlang 100%', ikon: '🏆', desc: 'Mencapai skor penuh 100% dalam aktiviti' },
  { id: 'Rajin Berusaha', nama: 'Rajin Berusaha', ikon: '🚀', desc: 'Menyiapkan sesi latihan berturut-turut' },
];

export const SudutGamifikasi: React.FC<GamifikasiProps> = ({
  murid,
  onTukarAvatar,
}) => {
  const handlePilihAvatar = (id: string) => {
    sounds.playCorrect();
    onTukarAvatar(murid.id, id);
    confetti({
      particleCount: 40,
      spread: 50,
      origin: { y: 0.6 },
      colors: ['#F472B6', '#38BDF8', '#FBBF24'],
    });
  };

  return (
    <div className="space-y-6">
      {/* Kad Profil Gamifikasi Murid */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-pink-100/90 via-purple-100/80 to-sky-100/90 border-2 border-pink-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
        <div className="flex flex-col md:flex-row items-center gap-4">
          <div className="w-20 h-20 rounded-3xl bg-white border-4 border-pink-300 flex items-center justify-center text-4xl shadow-md animate-bounce">
            {murid.avatarChibi === 'kancil'
              ? '🦌'
              : murid.avatarChibi === 'kucing'
              ? '🐱'
              : murid.avatarChibi === 'arnab'
              ? '🐰'
              : '🐻'}
          </div>

          <div>
            <span className="text-[11px] font-bold text-pink-700 uppercase tracking-widest bg-white/80 px-2.5 py-0.5 rounded-full border border-pink-200">
              Murid Bintang Pemulihan Khas
            </span>
            <h2 className="text-xl md:text-2xl font-black text-slate-800 mt-1">
              {murid.nama}
            </h2>
            <p className="text-xs text-slate-600">
              Kelas: <strong>{murid.kelas}</strong> • Tahap: <strong>{murid.tahun}</strong>
            </p>
          </div>
        </div>

        {/* Tabung Bintang Ganjaran */}
        <div className="p-4 rounded-2xl bg-white/90 border-2 border-amber-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 flex items-center justify-center text-amber-500">
            <Star className="w-7 h-7 fill-amber-400 text-amber-500" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-500 block">Bintang Terkumpul:</span>
            <span className="text-2xl font-black text-amber-600 tracking-tight">
              {murid.bintang} <span className="text-xs font-semibold text-slate-500">Bintang</span>
            </span>
          </div>
        </div>
      </div>

      {/* Pilihan Maskot Avatar Chibi */}
      <div className="bg-white p-5 rounded-3xl border-2 border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between border-b pb-2">
          <div className="flex items-center gap-2">
            <Smile className="w-4 h-4 text-sky-500" />
            <h3 className="text-sm md:text-base font-bold text-slate-800">
              Pilih Maskot Avatar Chibi Kegemaran Anda
            </h3>
          </div>
          <span className="text-xs text-slate-400">
            Tekan untuk bertukar maskot
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {SENARAI_AVATAR.map((av) => {
            const isSelected = murid.avatarChibi === av.id;
            return (
              <div
                key={av.id}
                onClick={() => handlePilihAvatar(av.id)}
                className={`p-4 rounded-2xl border-2 text-center cursor-pointer transition-all ${
                  isSelected
                    ? `${av.warna} ring-4 ring-pink-200 scale-105 shadow-sm`
                    : 'bg-slate-50/70 border-slate-200 hover:border-pink-300 hover:bg-pink-50/30'
                }`}
              >
                <div className="text-4xl mb-2">{av.ikon}</div>
                <div className="text-xs font-bold text-slate-800">{av.nama}</div>
                {isSelected && (
                  <span className="mt-1 inline-flex items-center gap-1 text-[10px] font-bold text-pink-700 bg-white/90 px-2 py-0.5 rounded-full border border-pink-200">
                    <CheckCircle2 className="w-3 h-3" /> Dipilih
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Papan Lencana Pencapaian Chibi */}
      <div className="bg-white p-5 rounded-3xl border-2 border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between border-b pb-2">
          <div className="flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-500" />
            <h3 className="text-sm md:text-base font-bold text-slate-800">
              Papan Lencana & Ganjaran Kemahiran
            </h3>
          </div>
          <span className="text-xs text-slate-400">
            {murid.lencana.length} daripada {SEMUA_LENCANA.length} telah diperoleh
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {SEMUA_LENCANA.map((lenc) => {
            const sudahDapat = murid.lencana.includes(lenc.id);

            return (
              <div
                key={lenc.id}
                className={`p-4 rounded-2xl border-2 flex items-start gap-3 transition ${
                  sudahDapat
                    ? 'bg-gradient-to-br from-amber-50/70 to-pink-50/50 border-amber-200 shadow-xs'
                    : 'bg-slate-50 border-slate-200 opacity-60'
                }`}
              >
                <div
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shrink-0 ${
                    sudahDapat ? 'bg-white shadow-xs' : 'bg-slate-200 grayscale'
                  }`}
                >
                  {lenc.ikon}
                </div>

                <div className="space-y-0.5 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-slate-800 truncate">
                      {lenc.nama}
                    </h4>
                    {sudahDapat ? (
                      <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                        Diperoleh
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold text-slate-400">
                        Belum buka
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 leading-snug">
                    {lenc.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
