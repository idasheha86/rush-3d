import { KonstrukDefinisi } from '../types';

export const SENARAI_KONSTRUK_KPM: KonstrukDefinisi[] = [
  {
    id: 1,
    kod: 'K1',
    tajuk: 'Keupayaan Membaca Huruf Vokal dan Konsonan',
    keterangan: 'Mengenal pasti dan menyebut huruf vokal (a, e, i, o, u) serta konsonan abjad rumi.',
    contoh: 'a, b, c, d, e, i, o, u, z',
    warna: '#FCE4EC', // pastel pink
  },
  {
    id: 2,
    kod: 'K2',
    tajuk: 'Keupayaan Membaca Suku Kata Terbuka (KV)',
    keterangan: 'Membunyikan gabungan satu konsonan dan satu vokal dengan sebutan yang lancar.',
    contoh: 'ba, bi, bu, ca, ci, cu, da, di, du',
    warna: '#FFF3E0', // pastel peach
  },
  {
    id: 3,
    kod: 'K3',
    tajuk: 'Keupayaan Membaca Perkataan Suku Kata Terbuka (KV + KV)',
    keterangan: 'Membaca dan memadankan perkataan dua suku kata terbuka berdasarkan objek.',
    contoh: 'buku, bola, ceri, mata, topi, kuku',
    warna: '#FFFDE7', // pastel lemon
  },
  {
    id: 4,
    kod: 'K4',
    tajuk: 'Keupayaan Membaca Suku Kata Tertutup (KVK)',
    keterangan: 'Membunyikan suku kata yang berakhir dengan huruf konsonan.',
    contoh: 'bas, beg, bot, tin, gam, pen, kek',
    warna: '#E8F5E9', // pastel mint
  },
  {
    id: 5,
    kod: 'K5',
    tajuk: 'Keupayaan Membaca Perkataan (V + KV)',
    keterangan: 'Membaca perkataan yang bermula dengan huruf vokal diikuti suku kata terbuka.',
    contoh: 'ubi, abu, api, ibu, aki, alu',
    warna: '#E1F5FE', // pastel blue
  },
  {
    id: 6,
    kod: 'K6',
    tajuk: 'Keupayaan Membaca Perkataan (V + KVK)',
    keterangan: 'Membaca perkataan vokal di hadapan dan suku kata tertutup di belakang.',
    contoh: 'ayam, ikan, otak, adik, epal, itik',
    warna: '#F3E5F5', // pastel lavender
  },
  {
    id: 7,
    kod: 'K7',
    tajuk: 'Keupayaan Membaca Perkataan (KV + KVK)',
    keterangan: 'Membaca perkataan suku kata terbuka diikuti suku kata tertutup.',
    contoh: 'cawan, gajah, pokok, rumah, katak, jarum',
    warna: '#E0F2FE', // pastel sky
  },
  {
    id: 8,
    kod: 'K8',
    tajuk: 'Keupayaan Membaca Perkataan (KVK + KV)',
    keterangan: 'Membaca perkataan suku kata tertutup di hadapan dan terbuka di belakang.',
    contoh: 'lampu, pintu, lembu, kunci, bomba, teksi',
    warna: '#FCE7F3', // pastel rose
  },
  {
    id: 9,
    kod: 'K9',
    tajuk: 'Keupayaan Membaca Perkataan (KVK + KVK)',
    keterangan: 'Membaca perkataan dua suku kata tertutup berangkai.',
    contoh: 'bintang, kertas, lompat, cermin, rumput, dompet',
    warna: '#FEF3C7', // pastel amber
  },
  {
    id: 10,
    kod: 'K10',
    tajuk: 'Keupayaan Membaca Perkataan Diftong & Vokal Berganding',
    keterangan: 'Membaca perkataan yang mengandungi sebutan diftong (ai, au, oi) dan vokal berganding.',
    contoh: 'pulau, tupai, daun, buah, pisau, limau, kerbau',
    warna: '#DCFCE7', // pastel emerald
  },
  {
    id: 11,
    kod: 'K11',
    tajuk: 'Keupayaan Membaca Perkataan Digraf & Konsonan Bergabung',
    keterangan: 'Membaca perkataan yang mengandungi digraf (ng, ny, sy, kh, gh) dan konsonan bergabung (tr, st, bl).',
    contoh: 'nyanyi, bunga, khemah, trompet, singa, stoking',
    warna: '#F1F5F9', // pastel slate
  },
  {
    id: 12,
    kod: 'K12',
    tajuk: 'Keupayaan Membaca dan Memahami Ayat Mudah',
    keterangan: 'Membaca ayat mudah, menyusun kata kerja aktiviti bersiri, dan memahami maksud petikan harian.',
    contoh: 'Ibu membakar sate. Ayah bernyanyi riang. Datuk dan nenek berehat gembira.',
    warna: '#FDE047', // soft sun
  },
];
